<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // 1. إنشاء الأدوار (Roles)
        $adminRole = Role::create(['name' => 'admin', 'display_name' => 'المدير العام']);
        $hrRole = Role::create(['name' => 'hr_manager', 'display_name' => 'مدير الموارد البشرية']);
        $sportsRole = Role::create(['name' => 'sports_manager', 'display_name' => 'رئيس وحدة رياضية']);
        $societyRole = Role::create(['name' => 'society_manager', 'display_name' => 'رئيس قسم الجمعيات']);
        $userRole = Role::create(['name' => 'user', 'display_name' => 'مواطن/عضو']);

        // 2. إنشاء حساب المدير العام (Admin User)
        $admin = User::create([
            'name' => 'Admin DCMS',
            'email' => 'admin@dcms.dz',
            'password' => Hash::make('password123'), // كلمة المرور الأولية
            'phone' => '0600000000',
            'status' => 'active',
            'email_verified_at' => now(),
        ]);

        // 3. منح صلاحيات المدير الكاملة
        $admin->assignRole($adminRole);

        $this->command->info('تم إنشاء حساب المدير بنجاح!');
        $this->command->info('البريد: admin@dcms.dz');
        $this->command->info('كلمة السر: password123');
    }
}
