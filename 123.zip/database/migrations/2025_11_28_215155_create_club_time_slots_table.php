<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateClubTimeSlotsTable extends Migration
{
    public function up(): void
    {
        Schema::create('club_time_slots', function (Blueprint $table) {
            $table->id();

            $table->foreignId('club_id')
                ->constrained()
                ->cascadeOnDelete();

            $table->foreignId('facility_id')
                ->constrained()
                ->cascadeOnDelete();

            $table->string('sport_activity');
            $table->string('day_of_week');
            $table->time('start_time');
            $table->time('end_time');

            $table->unsignedInteger('capacity');
            $table->unsignedInteger('current_count')->default(0);

            $table->boolean('is_active')->default(true);

            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('club_time_slots');
    }
}
