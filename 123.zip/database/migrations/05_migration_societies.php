<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('sports_societies', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->text('description')->nullable();
            $table->string('president_name');
            $table->string('president_email');
            $table->string('president_phone');
            $table->string('president_national_id');
            $table->string('headquarters_location')->nullable();
            $table->integer('members_count')->default(0);
            $table->enum('status', ['draft', 'pending', 'approved', 'rejected', 'suspended'])->default('draft');
            $table->text('rejection_reason')->nullable();
            $table->unsignedBigInteger('approved_by')->nullable();
            $table->dateTime('approved_at')->nullable();
            $table->string('license_document')->nullable();
            $table->string('president_id_document')->nullable();
            $table->foreign('approved_by')->references('id')->on('users')->onDelete('set null');
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::create('society_agreements', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('society_id');
            $table->string('agreement_number')->unique();
            $table->dateTime('start_date');
            $table->dateTime('end_date');
            $table->integer('trainers_count');
            $table->integer('sessions_per_week');
            $table->time('session_start_time');
            $table->time('session_end_time');
            $table->enum('days', ['saturday', 'sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday'])->nullable();
            $table->text('agreement_terms')->nullable();
            $table->decimal('monthly_fee', 10, 2);
            $table->enum('status', ['draft', 'pending_approval', 'active', 'ended', 'cancelled'])->default('draft');
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('approved_by')->nullable();
            $table->dateTime('approved_at')->nullable();
            $table->string('agreement_document')->nullable();
            $table->foreign('society_id')->references('id')->on('sports_societies')->onDelete('cascade');
            $table->foreign('created_by')->references('id')->on('users')->onDelete('set null');
            $table->foreign('approved_by')->references('id')->on('users')->onDelete('set null');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('society_agreements');
        Schema::dropIfExists('sports_societies');
    }
};
