<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('members', function (Blueprint $table) {
            $table->id();
            $table->string('registration_number')->unique()->nullable();
            $table->string('first_name');
            $table->string('last_name');
            $table->date('birth_date');
            $table->string('birth_place');
            $table->string('gender');
            $table->string('address');
            $table->string('phone');
            
            // العلاقات
            $table->unsignedBigInteger('facility_id')->nullable();
            $table->string('sport_type');
            $table->string('time_slot')->nullable();
            
            // الوثائق
            $table->string('doc_photo')->nullable();
            $table->string('doc_identity')->nullable();
            $table->string('doc_medical')->nullable();
            $table->string('doc_parental')->nullable();
            
            // الحالة
            $table->boolean('is_paid')->default(false);
            $table->string('status')->default('pending');
            $table->text('rejection_reason')->nullable();
            
            $table->timestamps();
            
            $table->foreign('facility_id')->references('id')->on('facilities')->nullOnDelete();
        });
    }
    public function down(): void { Schema::dropIfExists('members'); }
};
