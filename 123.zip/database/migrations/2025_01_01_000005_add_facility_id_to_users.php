<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::table('users', function (Blueprint $table) {
            if (!Schema::hasColumn('users', 'facility_id')) {
                $table->unsignedBigInteger('facility_id')->nullable();
                $table->foreign('facility_id')->references('id')->on('facilities')->nullOnDelete();
            }
        });
    }
    public function down(): void { 
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('facility_id');
        });
    }
};
