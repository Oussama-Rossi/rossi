<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('sports_events', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->text('description')->nullable();
            $table->enum('event_type', ['match', 'tournament', 'championship', 'training', 'other'])->default('match');
            $table->dateTime('event_date');
            $table->string('location')->nullable();
            $table->string('home_team')->nullable();
            $table->string('away_team')->nullable();
            $table->integer('total_tickets');
            $table->integer('available_tickets');
            $table->decimal('ticket_price', 10, 2);
            $table->string('image')->nullable();
            $table->enum('status', ['scheduled', 'ongoing', 'finished', 'cancelled'])->default('scheduled');
            $table->unsignedBigInteger('created_by');
            $table->foreign('created_by')->references('id')->on('users');
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::create('event_tickets', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('event_id');
            $table->unsignedBigInteger('user_id');
            $table->string('ticket_number')->unique();
            $table->string('qr_code')->unique();
            $table->enum('status', ['available', 'sold', 'used', 'cancelled'])->default('available');
            $table->decimal('price', 10, 2);
            $table->dateTime('purchased_at')->nullable();
            $table->dateTime('used_at')->nullable();
            $table->unsignedBigInteger('sold_to')->nullable();
            $table->foreign('event_id')->references('id')->on('sports_events')->onDelete('cascade');
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            $table->foreign('sold_to')->references('id')->on('users')->onDelete('set null');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('event_tickets');
        Schema::dropIfExists('sports_events');
    }
};
