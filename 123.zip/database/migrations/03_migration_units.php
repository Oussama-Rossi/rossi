<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('sports_units', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->text('description')->nullable();
            $table->enum('type', ['swimming_pool', 'football_field', 'sports_hall', 'tennis_court', 'other'])->default('other');
            $table->integer('capacity')->nullable();
            $table->decimal('price_per_hour', 10, 2)->nullable();
            $table->string('location')->nullable();
            $table->text('amenities')->nullable();
            $table->string('image')->nullable();
            $table->boolean('is_available')->default(true);
            $table->time('opening_time')->default('08:00');
            $table->time('closing_time')->default('20:00');
            $table->unsignedBigInteger('manager_id')->nullable();
            $table->foreign('manager_id')->references('id')->on('users');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('sports_units');
    }
};
