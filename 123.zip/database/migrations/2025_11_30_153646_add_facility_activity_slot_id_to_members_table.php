<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('members', function (Blueprint $table) {
            $table->foreignId('facility_activity_slot_id')
                ->nullable()
                ->after('club_time_slot_id')
                ->constrained('facility_activity_slots')
                ->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('members', function (Blueprint $table) {
            $table->dropForeign(['facility_activity_slot_id']);
            $table->dropColumn('facility_activity_slot_id');
        });
    }
};
