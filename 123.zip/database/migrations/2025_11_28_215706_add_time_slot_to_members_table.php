<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddTimeSlotToMembersTable extends Migration
{
public function up(): void
{
    Schema::table('members', function (Blueprint $table) {
        $table->foreignId('club_time_slot_id')
            ->nullable()
            ->constrained()
            ->nullOnDelete();
    });
}


    public function down(): void
    {
        Schema::table('members', function (Blueprint $table) {
            $table->dropForeign(['club_time_slot_id']);
            $table->dropColumn('club_time_slot_id');
        });
    }
}
