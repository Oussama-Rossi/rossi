<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('football_matches', function (Blueprint $table) {
            $table->id();
            $table->string('team_home');
            $table->string('team_home_logo')->nullable();
            $table->string('team_away');
            $table->string('team_away_logo')->nullable();
            $table->string('championship');
            $table->dateTime('match_date');
            $table->string('stadium')->default('ملعب سويداني بوجمعة');
            $table->decimal('ticket_price', 8, 2);
            $table->integer('total_seats')->default(5000);
            $table->boolean('is_selling')->default(true);
            $table->timestamps();
        });

        Schema::create('tickets', function (Blueprint $table) {
            $table->id();
            $table->string('ticket_number')->unique();
            $table->foreignId('football_match_id')->constrained('football_matches')->cascadeOnDelete();
            $table->string('full_name');
            $table->string('phone');
            $table->decimal('price', 8, 2);
            $table->boolean('is_scanned')->default(false);
            $table->timestamps();
        });
    }
    public function down(): void { 
        Schema::dropIfExists('tickets');
        Schema::dropIfExists('football_matches');
    }
};
