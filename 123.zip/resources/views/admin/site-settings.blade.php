<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إعدادات الموقع - شعار الديوان</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700;900&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Tajawal', sans-serif; background-color: #020617; }
    </style>
</head>
<body class="min-h-screen text-white">

<div class="max-w-3xl mx-auto px-4 py-10">
    <div class="flex items-center justify-between mb-6">
        <div>
            <h1 class="text-2xl md:text-3xl font-extrabold text-emerald-400 mb-1">
                إعدادات الموقع
            </h1>
            <p class="text-sm text-slate-300">
                تعديل شعار الديوان المستخدم في الواجهة العامة.
            </p>
        </div>

        <a href="{{ route('home') }}"
           class="inline-flex items-center px-4 py-2 rounded-lg text-xs font-bold text-slate-900 bg-slate-200 hover:bg-slate-100 transition">
            ⬅ الصفحة الرئيسية
        </a>
    </div>

    @if(session('success'))
        <div class="mb-4 bg-emerald-500/10 border border-emerald-500 text-emerald-200 text-sm px-4 py-3 rounded-xl">
            {{ session('success') }}
        </div>
    @endif

    @if ($errors->any())
        <div class="mb-4 bg-red-500/10 border border-red-500 text-red-200 text-sm px-4 py-3 rounded-xl">
            <ul class="list-disc list-inside space-y-1">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="bg-slate-900/80 border border-slate-700 rounded-2xl p-6 space-y-6">
        <div>
            <h2 class="text-lg font-bold mb-2">الشعار الحالي</h2>

            @if($logoExists)
                <div class="flex items-center gap-4">
                    <div class="bg-slate-800 rounded-xl p-3 border border-slate-700">
                        <img src="{{ asset('storage/logo.png') }}" alt="شعار الديوان" class="h-20 object-contain">
                    </div>
                    <p class="text-xs text-slate-300">
                        هذا هو الشعار المعروض حالياً في الصفحة الرئيسية وبقية الواجهات.
                    </p>
                </div>
            @else
                <p class="text-sm text-slate-300">
                    لم يتم رفع شعار بعد. سيتم عرض النص الافتراضي:
                    <span class="font-bold">ديوان المركب المتعدد الرياضات لولاية قالمة</span>
                </p>
            @endif
        </div>

        <form action="{{ route('admin.site-settings.update') }}" method="POST" enctype="multipart/form-data" class="space-y-4">
            @csrf

            <div>
                <label class="block text-sm font-bold mb-2 text-slate-200">
                    تحميل شعار جديد
                </label>
                <input type="file" name="logo"
                       accept="image/*"
                       class="block w-full text-sm text-slate-200
                              file:mr-3 file:py-2 file:px-4
                              file:rounded-lg file:border-0
                              file:text-sm file:font-semibold
                              file:bg-emerald-500 file:text-slate-900
                              hover:file:bg-emerald-400
                              bg-slate-900 border border-slate-700 rounded-lg p-1.5">
                <p class="text-[11px] text-slate-400 mt-1">
                    يفضل استخدام صورة بصيغة PNG بخلفية شفافة، حجم أقصى 2 ميغابايت.
                </p>
            </div>

            <div class="flex items-center justify-end gap-3 pt-3">
                <a href="{{ route('home') }}"
                   class="px-4 py-2 rounded-lg text-xs font-bold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-600 transition">
                    إلغاء
                </a>
                <button type="submit"
                        class="px-5 py-2.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-xs font-bold text-slate-900 transition shadow-lg">
                    حفظ الشعار
                </button>
            </div>
        </form>
    </div>
</div>

</body>
</html>
