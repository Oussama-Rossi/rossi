<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>طلب انخراط رياضي - ديوان المركب المتعدد الرياضات</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700;900&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Tajawal', sans-serif; background-color: #f3f4f6; }
    </style>
</head>
<body class="py-10">

<div class="max-w-4xl mx-auto px-4">
    <!-- ترويسة الصفحة -->
    <div class="text-center mb-10">
        <div class="flex items-center justify-center mb-3">
            @if(file_exists(public_path('storage/logo.png')))
                <img src="{{ asset('storage/logo.png') }}" alt="شعار الديوان"
                     class="h-16 md:h-20 object-contain">
            @else
                <h1 class="text-3xl font-extrabold text-blue-900">
                    ديوان المركب المتعدد الرياضات لولاية قالمة
                </h1>
            @endif
        </div>
        <p class="text-gray-600">بوابة التسجيل الإلكتروني للموسم الرياضي 2025/2026</p>
    </div>

    <div class="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100">
        <div class="bg-gradient-to-r from-blue-900 to-blue-800 p-6 text-center">
            <h2 class="text-2xl font-bold text-white">استمارة طلب انخراط</h2>
            <p class="text-blue-200 mt-1 text-sm">يرجى ملء البيانات بدقة لإنشاء حسابك وملفك الرياضي</p>
        </div>

        <!-- زر الصفحة الرئيسية -->
        <div class="px-8 pt-4 flex justify-end">
            <a href="{{ route('home') }}"
               class="inline-flex items-center px-4 py-2 rounded-lg text-sm font-bold text-blue-900 bg-blue-50 border border-blue-200 hover:bg-blue-100 hover:border-blue-300 transition">
                ⬅ العودة إلى الصفحة الرئيسية
            </a>
        </div>

        <!-- عرض الأخطاء إن وجدت -->
        @if ($errors->any())
            <div class="bg-red-50 border-r-4 border-red-500 p-4 m-6 mb-0">
                <div class="flex">
                    <div class="mr-3">
                        <h3 class="text-sm font-medium text-red-800">يرجى تصحيح الأخطاء التالية:</h3>
                        <ul class="mt-2 list-disc list-inside text-sm text-red-700">
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>
        @endif

        <form action="{{ route('public.join.store') }}" method="POST" class="p-8 space-y-8">
            @csrf

            <!-- 0. اختيار نوع الانخراط -->
            <div class="mb-4 bg-slate-900 text-white p-5 rounded-xl border border-slate-800">
                <h3 class="text-lg font-bold mb-3 flex items-center">
                    <span class="bg-emerald-500 text-black w-8 h-8 rounded-full flex items-center justify-center ml-3 text-sm">0</span>
                    اختر نوع الانخراط
                </h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <label class="flex items-start gap-3 p-3 rounded-xl border border-slate-700 bg-slate-800 cursor-pointer hover:border-emerald-400 transition">
                        <input type="radio" name="subscription_type" value="diwan" class="mt-1 w-4 h-4"
                               {{ old('subscription_type') === 'diwan' ? 'checked' : '' }} required>
                        <div>
                            <div class="font-bold">انخراط لدى الديوان مباشرة</div>
                            <div class="text-xs text-slate-300 mt-1">
                                أنشطة تشرف عليها الإدارة مباشرة داخل المرافق (دون ربط بجمعية معينة).
                            </div>
                        </div>
                    </label>

                    <label class="flex items-start gap-3 p-3 rounded-xl border border-slate-700 bg-slate-800 cursor-pointer hover:border-emerald-400 transition">
                        <input type="radio" name="subscription_type" value="club" class="mt-1 w-4 h-4"
                               {{ old('subscription_type') === 'club' ? 'checked' : '' }}>
                        <div>
                            <div class="font-bold">انخراط عبر جمعية / نادي</div>
                            <div class="text-xs text-slate-300 mt-1">
                                اختيار جمعية رياضية تنشط في مرفق معين مع حصص وسعات يحددها رئيس الجمعية.
                            </div>
                        </div>
                    </label>
                </div>
            </div>

            <!-- 1. بيانات الحساب -->
            <div class="mb-4 bg-blue-50 p-6 rounded-xl border border-blue-100">
                <h3 class="text-lg font-bold text-blue-900 mb-4 flex items-center">
                    <span class="bg-blue-900 text-white w-8 h-8 rounded-full flex items-center justify-center ml-3 text-sm">1</span>
                    بيانات الحساب (للدخول لاحقاً)
                </h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-2">البريد الإلكتروني</label>
                        <input type="email" name="email" value="{{ old('email') }}" required
                               class="w-full border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500 p-3 border"
                               placeholder="email@example.com">
                    </div>
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-2">كلمة المرور</label>
                        <input type="password" name="password" required
                               class="w-full border-gray-300 rounded-lg shadow-sm focus:border-blue-500 focus:ring-blue-500 p-3 border"
                               placeholder="******">
                        <p class="text-xs text-gray-500 mt-1">يجب أن تكون 8 أحرف على الأقل</p>
                    </div>
                </div>
            </div>

            <!-- 2. المعلومات الشخصية -->
            <div>
                <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                    <span class="bg-gray-700 text-white w-8 h-8 rounded-full flex items-center justify-center ml-3 text-sm">2</span>
                    المعلومات الشخصية
                </h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-2">اللقب</label>
                        <input type="text" name="last_name" value="{{ old('last_name') }}" required class="w-full border rounded-lg p-3 bg-gray-50 focus:bg-white border-gray-200">
                    </div>
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-2">الاسم</label>
                        <input type="text" name="first_name" value="{{ old('first_name') }}" required class="w-full border rounded-lg p-3 bg-gray-50 focus:bg-white border-gray-200">
                    </div>
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-2">تاريخ الميلاد</label>
                        <input type="date" name="birth_date" value="{{ old('birth_date') }}" required class="w-full border rounded-lg p-3 bg-gray-50 focus:bg-white border-gray-200">
                    </div>
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-2">مكان الميلاد</label>
                        <input type="text" name="birth_place" value="{{ old('birth_place') }}" required class="w-full border rounded-lg p-3 bg-gray-50 focus:bg-white border-gray-200">
                    </div>
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-2">الجنس</label>
                        <select name="gender" class="w-full border rounded-lg p-3 bg-gray-50 focus:bg-white border-gray-200">
                            <option value="male" {{ old('gender') === 'male' ? 'selected' : '' }}>ذكر</option>
                            <option value="female" {{ old('gender') === 'female' ? 'selected' : '' }}>أنثى</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-2">رقم الهاتف</label>
                        <input type="tel" name="phone" value="{{ old('phone') }}" required class="w-full border rounded-lg p-3 bg-gray-50 focus:bg-white border-gray-200">
                    </div>
                    <div class="col-span-1 md:col-span-2">
                        <label class="block text-sm font-bold text-gray-700 mb-2">العنوان الكامل</label>
                        <input type="text" name="address" value="{{ old('address') }}" required class="w-full border rounded-lg p-3 bg-gray-50 focus:bg-white border-gray-200" placeholder="الحي، الشارع، البلدية...">
                    </div>
                </div>
            </div>

            <!-- 3. اختيار النشاط + المرفق/الجمعية + الحصص -->
            <div>
                <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                    <span class="bg-gray-700 text-white w-8 h-8 rounded-full flex items-center justify-center ml-3 text-sm">3</span>
                    النشاط الرياضي والمرفق / الجمعية
                </h3>

                <!-- جزء الديوان -->
                <div id="diwan-section" class="hidden space-y-4">
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 p-4 border border-gray-200 rounded-xl bg-gray-50">
                        <div>
                            <label class="block text-sm font-bold text-gray-700 mb-2">المرفق الرياضي</label>
                            <select name="facility_id" id="facilitySelect" onchange="updateOptions()" class="w-full border rounded-lg p-3 bg-white">
                                <option value="">اختر المرفق...</option>
                                @foreach($facilities as $facility)
                                    <option value="{{ $facility->id }}"
                                            data-sports='@json($facility->available_sports ?? [])'
                                            data-hours='@json($facility->work_hours ?? [])'>
                                        {{ $facility->name }}
                                    </option>
                                @endforeach
                            </select>
                        </div>

                        <div>
                            <label class="block text-sm font-bold text-gray-700 mb-2">الرياضة</label>
                            <select name="sport_type" id="sportSelect" class="w-full border rounded-lg p-3 bg-white">
                                <option value="">اختر المرفق أولاً</option>
                            </select>
                        </div>

                        <div>
                            <label class="block text-sm font-bold text-gray-700 mb-2">الحصة (بالتوقيت والسعة)</label>
                            <select name="facility_activity_slot_id" id="timeSelect" class="w-full border rounded-lg p-3 bg-white">
                                <option value="">اختر المرفق والنشاط أولاً</option>
                            </select>
                        </div>
                    </div>

                    <p class="text-xs text-gray-500 mt-2">
                        ملاحظة: الانخراط لدى الديوان يعتمد على التنظيم الداخلي للوحدة، مع احترام السعة القصوى لكل حصة.
                    </p>
                </div>

                <!-- جزء الجمعيات / النوادي -->
                <div id="club-section" class="hidden space-y-4">
                    <div class="bg-slate-900 text-white p-4 rounded-xl border border-slate-800">
                        <p class="text-sm">
                            اختر جمعية ثم حصة زمنية ضمن سعتها المتاحة. لا يمكن اختيار حصة ممتلئة.
                        </p>
                    </div>

                    <!-- اختيار النادي -->
                    <div>
                        <label class="block text-sm font-bold mb-2 text-gray-700">اختر النادي / الجمعية</label>
                        <select id="clubSelect" class="w-full border rounded-lg p-3 bg-white text-sm">
                            <option value="">كل الجمعيات</option>
                            @php
                                $clubsFromSlots = $timeSlots->pluck('club')->filter()->unique('id');
                            @endphp
                            @foreach($clubsFromSlots as $club)
                                <option value="{{ $club->id }}">{{ $club->name }}</option>
                            @endforeach
                        </select>
                        <p class="text-[11px] text-gray-500 mt-1">
                            يمكنك عرض كل الحصص أو تصفيتها حسب جمعية معيّنة.
                        </p>
                    </div>

                    {{-- اختيار الحصة من timeSlots --}}
                    <div class="mt-2">
                        <label class="block text-sm font-bold mb-2 text-gray-700">اختر الحصة الزمنية في الجمعية</label>

                        @if($timeSlots->count())
                            <div id="clubSlotsContainer" class="space-y-2 text-sm">
                                @foreach($timeSlots as $slot)
                                    <label class="club-slot flex items-center gap-2 bg-slate-900/90 border border-slate-700 rounded-lg px-3 py-2 cursor-pointer"
                                           data-club-id="{{ optional($slot->club)->id }}">
                                        <input type="radio" name="club_time_slot_id" value="{{ $slot->id }}"
                                               class="w-4 h-4"
                                               {{ old('club_time_slot_id') == $slot->id ? 'checked' : '' }}>
                                        <div>
                                            <div class="font-bold text-white">
                                                {{ $slot->day_of_week }}
                                                | {{ \Illuminate\Support\Str::of($slot->start_time)->substr(0,5) }}
                                                - {{ \Illuminate\Support\Str::of($slot->end_time)->substr(0,5) }}
                                            </div>
                                            <div class="text-xs text-gray-300">
                                                النادي: {{ $slot->club->name ?? 'غير محدد' }}
                                                — الوحدة: {{ $slot->facility->name ?? 'غير محددة' }}
                                            </div>
                                            <div class="text-[11px] text-gray-400">
                                                المحجوز: {{ $slot->current_count }} / {{ $slot->capacity }}
                                                — المتبقي: {{ $slot->capacity - $slot->current_count }}
                                            </div>
                                        </div>
                                    </label>
                                @endforeach
                            </div>
                        @else
                            <p class="text-xs text-amber-600">
                                لا توجد حصص جمعيات متاحة حالياً، يرجى العودة لاحقاً أو اختيار انخراط لدى الديوان.
                            </p>
                        @endif
                    </div>
                </div>
            </div>

            <div class="bg-yellow-50 p-4 rounded-lg mb-4 flex items-start border border-yellow-200">
                <span class="text-2xl mr-3">📄</span>
                <p class="text-sm text-yellow-800 pt-1">
                    <strong>مرحلة أخيرة:</strong> بعد الضغط على "تأكيد التسجيل"، سيتم إنشاء حسابك وتحميل "استمارة الانخراط" بصيغة PDF.
                    يجب طباعتها، المصادقة عليها من طرف الطبيب (والولي الشرعي للقصر)، ثم إيداعها في إدارة المرفق لدفع الحقوق وتفعيل حسابك.
                </p>
            </div>

            <button type="submit"
                    class="w-full bg-green-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-green-700 transition shadow-lg transform hover:-translate-y-1">
                تأكيد التسجيل وطباعة الاستمارة
            </button>
        </form>
    </div>

    <div class="text-center mt-8 text-gray-500 text-sm">
        &copy; {{ date('Y') }} ديوان المركب المتعدد الرياضات - جميع الحقوق محفوظة
    </div>
</div>

{{-- تمرير حصص الديوان للـ JS --}}
<script>
    window.facilitySlots = @json($facilitySlots);
</script>

<script>
    function toggleSubscriptionType(type) {
        const diwanSection = document.getElementById('diwan-section');
        const clubSection  = document.getElementById('club-section');

        if (type === 'diwan') {
            diwanSection.classList.remove('hidden');
            clubSection.classList.add('hidden');
        } else if (type === 'club') {
            clubSection.classList.remove('hidden');
            diwanSection.classList.add('hidden');
        }
    }

    document.addEventListener('DOMContentLoaded', () => {
        const oldType = "{{ old('subscription_type') }}";
        if (oldType === 'diwan') toggleSubscriptionType('diwan');
        else if (oldType === 'club') toggleSubscriptionType('club');

        // تبديل نوع الانخراط ديناميكياً
        document.querySelectorAll('input[name="subscription_type"]').forEach(r => {
            r.addEventListener('change', e => toggleSubscriptionType(e.target.value));
        });

        // تصفية الحصص حسب النادي
        const clubSelect = document.getElementById('clubSelect');
        if (clubSelect) {
            clubSelect.addEventListener('change', () => {
                const selectedClubId = clubSelect.value;
                document.querySelectorAll('.club-slot').forEach(el => {
                    const clubId = el.getAttribute('data-club-id');
                    if (!selectedClubId || clubId === selectedClubId) {
                        el.classList.remove('hidden');
                    } else {
                        el.classList.add('hidden');
                    }
                });
            });
        }
    });

    function updateOptions() {
        const facilitySelect = document.getElementById('facilitySelect');
        const sportSelect = document.getElementById('sportSelect');
        const timeSelect = document.getElementById('timeSelect');

        const facilitySlots = window.facilitySlots || [];

        sportSelect.innerHTML = '<option value="">اختر...</option>';
        timeSelect.innerHTML = '<option value="">اختر المرفق والنشاط أولاً</option>';

        const selectedOption = facilitySelect.options[facilitySelect.selectedIndex];

        if (!selectedOption || !selectedOption.value) {
            return;
        }

        // 1) تحميل الرياضات من available_sports
        let sports = [];
        if (selectedOption.dataset.sports) {
            try {
                sports = JSON.parse(selectedOption.dataset.sports) || [];
            } catch (e) {
                sports = [];
            }
        }

        if (sports.length > 0) {
            sportSelect.innerHTML = '<option value="">اختر الرياضة...</option>';
            sports.forEach(sport => {
                if (sport) sportSelect.add(new Option(sport, sport));
            });
        } else {
            sportSelect.innerHTML = '<option value="">لا توجد رياضات محددة</option>';
        }

        // عند اختيار رياضة نملأ الحصص
        sportSelect.onchange = function () {
            const facilityId = parseInt(selectedOption.value, 10);
            const chosenSport = this.value;

            timeSelect.innerHTML = '<option value="">اختر الحصة...</option>';

            if (!facilityId || !chosenSport) {
                return;
            }

            const slots = facilitySlots.filter(slot =>
                slot.facility_id === facilityId &&
                slot.sport_type === chosenSport
            );

            if (!slots.length) {
                timeSelect.innerHTML = '<option value="">لا توجد حصص لهذا النشاط حالياً</option>';
                return;
            }

            slots.forEach(slot => {
                const remaining = slot.capacity - slot.current_count;
                const start = slot.start_time ? slot.start_time.slice(0, 5) : '';
                const end   = slot.end_time ? slot.end_time.slice(0, 5) : '';
                const label = `${slot.day_of_week ?? ''} ${start} - ${end} — المحجوز: ${slot.current_count}/${slot.capacity} — المتبقي: ${remaining}`;

                const option = new Option(label, slot.id);
                if (remaining <= 0) {
                    option.disabled = true;
                    option.textContent += ' (ممتلئة)';
                }
                timeSelect.add(option);
            });
        };
    }
</script>

</body>
</html>
