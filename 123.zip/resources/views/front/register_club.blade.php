<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>اعتماد نادي رياضي جديد</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700;900&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Tajawal', sans-serif; }
    </style>
</head>
<body class="bg-slate-950 text-slate-100">

<div class="min-h-screen flex flex-col">
    <main class="flex-1 px-3 py-3 sm:px-4 sm:py-6">
        <div class="w-full max-w-2xl mx-auto">
            <div class="bg-slate-900/95 rounded-2xl shadow-xl border border-slate-800 overflow-hidden">

                <!-- الهيدر -->
                <div class="bg-gradient-to-r from-blue-900 to-sky-700 px-4 py-4 sm:px-6 sm:py-5 text-center">
                    <h1 class="text-xl sm:text-2xl font-extrabold text-white mb-1">
                        طلب اعتماد حساب نادي رياضي
                    </h1>
                    <p class="text-[11px] sm:text-xs text-blue-100">
                        فضاء مخصص لرؤساء الجمعيات والنوادي الرياضية المعتمدة
                    </p>

                    <!-- أزرار التنقل -->
                    <div class="mt-3 flex flex-col sm:flex-row sm:justify-center gap-2">
                        <a href="{{ route('home') }}"
                           class="inline-flex justify-center items-center px-3 py-2 rounded-xl
                                  text-[11px] sm:text-xs font-bold
                                  bg-slate-900/70 text-slate-100 border border-slate-700
                                  hover:bg-slate-800 transition w-full sm:w-auto">
                            ⬅ العودة إلى الصفحة الرئيسية
                        </a>
                        <a href="{{ route('public.clubs') }}"
                           class="inline-flex justify-center items-center px-3 py-2 rounded-xl
                                  text-[11px] sm:text-xs font-bold
                                  bg-sky-500 text-black hover:bg-sky-400 transition
                                  w-full sm:w-auto">
                            قائمة الجمعيات / النوادي
                        </a>
                    </div>
                </div>

                <!-- الأخطاء -->
                @if ($errors->any())
                    <div class="px-4 pt-3 sm:px-5">
                        <div class="mb-3 bg-red-950/70 border border-red-500/70 text-red-100 px-3 py-2 rounded-xl text-[11px] sm:text-xs">
                            @foreach ($errors->all() as $error)
                                <div class="flex items-start gap-1.5">
                                    <span class="mt-0.5">•</span>
                                    <span>{{ $error }}</span>
                                </div>
                            @endforeach
                        </div>
                    </div>
                @endif

                <form action="{{ route('public.clubs.store') }}" method="POST" enctype="multipart/form-data"
                      class="px-4 pb-4 pt-3 sm:px-6 sm:pb-6 sm:pt-4 space-y-5">
                    @csrf

                    <!-- 1. حساب الرئيس -->
                    <section class="bg-slate-800/80 border border-slate-700 rounded-2xl p-3 sm:p-4">
                        <h3 class="text-sm font-bold text-sky-300 mb-2 flex items-center gap-2">
                            <span class="flex items-center justify-center w-6 h-6 rounded-full bg-sky-500 text-[11px] font-extrabold text-black">
                                1
                            </span>
                            معلومات حساب الرئيس (للدخول)
                        </h3>
                        <div class="space-y-3">
                            <div>
                                <label class="block text-[11px] font-bold mb-1 text-slate-200">
                                    البريد الإلكتروني الرسمي
                                </label>
                                <input type="email" name="email" value="{{ old('email') }}" required
                                       class="w-full rounded-xl border border-slate-600 bg-slate-900/80 px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500">
                            </div>
                            <div>
                                <label class="block text-[11px] font-bold mb-1 text-slate-200">
                                    كلمة المرور
                                </label>
                                <input type="password" name="password" required
                                       class="w-full rounded-xl border border-slate-600 bg-slate-900/80 px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500">
                                <p class="mt-1 text-[10px] text-slate-400">
                                    يجب أن تكون 8 أحرف على الأقل.
                                </p>
                            </div>
                        </div>
                    </section>

                    <!-- 2. بيانات النادي -->
                    <section class="bg-slate-800/60 border border-slate-700 rounded-2xl p-3 sm:p-4">
                        <h3 class="text-sm font-bold text-amber-300 mb-2 flex items-center gap-2">
                            <span class="flex items-center justify-center w-6 h-6 rounded-full bg-amber-400 text-[11px] font-extrabold text-black">
                                2
                            </span>
                            بيانات الجمعية / النادي
                        </h3>

                        <div class="space-y-3">
                            <div>
                                <label class="block text-[11px] font-bold mb-1 text-slate-200">
                                    اسم النادي (كما في الاعتماد)
                                </label>
                                <input type="text" name="club_name" value="{{ old('club_name') }}" required
                                       class="w-full rounded-xl border border-slate-600 bg-slate-900/80 px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500">
                            </div>
                            <div>
                                <label class="block text-[11px] font-bold mb-1 text-slate-200">
                                    رقم الاعتماد (Agrément)
                                </label>
                                <input type="text" name="registration_number" value="{{ old('registration_number') }}" required
                                       class="w-full rounded-xl border border-slate-600 bg-slate-900/80 px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500">
                            </div>
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                <div>
                                    <label class="block text-[11px] font-bold mb-1 text-slate-200">
                                        اسم الرئيس الكامل
                                    </label>
                                    <input type="text" name="president_name" value="{{ old('president_name') }}" required
                                           class="w-full rounded-xl border border-slate-600 bg-slate-900/80 px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500">
                                </div>
                                <div>
                                    <label class="block text-[11px] font-bold mb-1 text-slate-200">
                                        رقم الهاتف
                                    </label>
                                    <input type="text" name="phone" value="{{ old('phone') }}" required
                                           class="w-full rounded-xl border border-slate-600 bg-slate-900/80 px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500">
                                </div>
                            </div>

                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                <div>
                                    <label class="block text-[11px] font-bold mb-1 text-slate-200">
                                        النشاط الرئيسي
                                    </label>
                                    <select name="sport_activity"
                                            class="w-full rounded-xl border border-slate-600 bg-slate-900/80 px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500">
                                        <option value="كرة القدم"  @selected(old('sport_activity') === 'كرة القدم')>كرة القدم</option>
                                        <option value="كرة اليد"   @selected(old('sport_activity') === 'كرة اليد')>كرة اليد</option>
                                        <option value="السباحة"    @selected(old('sport_activity') === 'السباحة')>السباحة</option>
                                        <option value="الفنون القتالية" @selected(old('sport_activity') === 'الفنون القتالية')>الفنون القتالية</option>
                                        <option value="ألعاب القوى" @selected(old('sport_activity') === 'ألعاب القوى')>ألعاب القوى</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-[11px] font-bold mb-1 text-slate-200">
                                        شعار النادي (اختياري)
                                    </label>
                                    <input type="file" name="logo"
                                           class="w-full rounded-xl border border-slate-600 bg-slate-900/80 px-3 py-1.5 text-xs text-slate-200 file:mr-2 file:py-1 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-sky-500 file:text-black hover:file:bg-sky-400">
                                </div>
                            </div>

                            <div>
                                <label for="facility_id" class="block mb-1 text-[11px] font-bold text-slate-200">
                                    اختر الوحدة / المرفق الرياضي
                                </label>
                                <select name="facility_id" id="facility_id" required
                                        class="w-full rounded-xl border border-slate-600 bg-slate-900/80 px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500">
                                    <option value="">اختر الوحدة...</option>
                                    @foreach($facilities as $facility)
                                        <option value="{{ $facility->id }}" @selected(old('facility_id') == $facility->id)>
                                            {{ $facility->name }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </section>

                    <div class="bg-amber-50/5 border border-amber-500/40 text-amber-100 text-[11px] sm:text-xs rounded-2xl px-3 py-2.5">
                        <strong class="font-bold">تنبيه مهم:</strong>
                        <span class="ml-1">
                            الحساب لن يصبح نشطاً إلا بعد تقديم نسخة من اعتماد الجمعية (Agrément) للإدارة والمصادقة عليه.
                        </span>
                    </div>

                    <button type="submit"
                            class="w-full bg-sky-500 hover:bg-sky-400 text-black font-extrabold text-sm sm:text-base py-3 rounded-2xl shadow-lg shadow-sky-500/30 transition transform hover:-translate-y-0.5">
                        تسجيل النادي وطلب الاعتماد
                    </button>
                </form>
            </div>

            <div class="mt-3 text-center text-[11px] text-slate-500">
                &copy; {{ date('Y') }} ديوان المركب المتعدد الرياضات
            </div>
        </div>
    </main>
</div>

</body>
</html>
