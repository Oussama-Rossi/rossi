<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>بروفيل النادي</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700;900&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Tajawal', sans-serif; }
    </style>
</head>
<body class="bg-slate-950 text-slate-100">

    {{-- Navbar --}}
    <nav class="bg-slate-900/95 border-b border-slate-800 sticky top-0 z-50">
        <div class="w-full lg:max-w-4xl lg:mx-auto px-4 py-2.5 flex items-center justify-between gap-3">
            <div class="flex items-center gap-3">
                <div class="w-11 h-11 sm:w-12 sm:h-12 rounded-full border border-white/10 bg-slate-800 flex items-center justify-center overflow-hidden shrink-0">
                    @if($club->logo)
                        <img src="{{ asset('storage/'.$club->logo) }}" alt="شعار النادي" class="h-full w-full object-cover">
                    @else
                        <span class="text-2xl text-emerald-400">🛡️</span>
                    @endif
                </div>
                <div class="leading-tight">
                    <p class="text-[11px] text-slate-300">بروفيل النادي</p>
                    <p class="text-sm sm:text-base font-bold text-slate-50">
                        {{ $club->name }}
                    </p>
                </div>
            </div>

            <div class="flex items-center gap-2">
                {{-- زر لوحة النادي --}}
                <a href="{{ route('club.dashboard') }}"
                   class="hidden sm:flex px-3 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold shadow items-center gap-1 transition">
                    📊 <span>لوحة النادي</span>
                </a>

                {{-- زر الخروج --}}
                <form action="{{ route('public.logout') }}" method="POST" class="shrink-0">
                    @csrf
                    <button
                        class="px-3 py-2 rounded-lg bg-red-600 hover:bg-red-500 text-white text-xs font-bold shadow flex items-center gap-1 transition">
                        🚪 <span class="hidden sm:inline">خروج</span>
                    </button>
                </form>
            </div>
        </div>
    </nav>

    <main class="pb-8">
        <div class="w-full lg:max-w-4xl lg:mx-auto px-4 pt-4 lg:pt-6 space-y-4">

            {{-- كارت البروفيل --}}
            <section class="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-lg">
                <h1 class="text-lg sm:text-xl font-bold mb-4 text-center text-slate-50">
                    معلومات النادي
                </h1>

                <div class="space-y-3 text-sm sm:text-base text-slate-200">
                    <p><span class="text-slate-400">اسم النادي:</span> <span class="font-bold">{{ $club->name }}</span></p>
                    <p><span class="text-slate-400">رئيس النادي:</span> <span class="font-bold">{{ $club->president_name }}</span></p>
                    <p><span class="text-slate-400">الهاتف:</span> <span class="font-bold">{{ $club->phone }}</span></p>
                    <p><span class="text-slate-400">النشاط:</span> <span class="font-bold text-emerald-300">{{ $club->sport_activity }}</span></p>
                    <p><span class="text-slate-400">الوحدة:</span> <span class="font-bold">{{ optional($club->facility)->name ?? 'غير محددة' }}</span></p>
                    <p>
                        <span class="text-slate-400">الحالة:</span>
                        @if($club->is_active)
                            <span class="font-bold text-emerald-300">مفعل ✅</span>
                        @else
                            <span class="font-bold text-amber-300">في انتظار موافقة الإدارة ⏳</span>
                        @endif
                    </p>
                </div>
            </section>

            {{-- أزرار الرجوع --}}
            <section class="flex flex-col sm:flex-row gap-3">
                <a href="{{ route('public.clubs') }}"
                   class="flex-1 text-center px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs sm:text-sm font-bold text-slate-100 border border-slate-700 transition">
                    ← الرجوع إلى صفحة النوادي
                </a>

                <a href="{{ route('home') }}"
                   class="flex-1 text-center px-4 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-xs sm:text-sm font-bold text-white shadow transition">
                    ← الرجوع إلى الصفحة الرئيسية
                </a>
            </section>

            <footer class="pt-4 text-center text-[10px] text-slate-600">
                &copy; {{ date('Y') }} ديوان المركب المتعدد الرياضات
            </footer>
        </div>
    </main>

</body>
</html>
