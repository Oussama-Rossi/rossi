<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>المرافق الرياضية - ديوان المركب المتعدد الرياضات</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700;900&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Tajawal', sans-serif; background-color: #0f172a; }
    </style>
</head>
<body class="min-h-screen text-white">

<div class="max-w-6xl mx-auto px-4 py-10">
    <div class="flex items-center justify-between mb-8">
        <div>
            <h1 class="text-2xl md:text-3xl font-extrabold text-emerald-400 mb-1">
                المرافق الرياضية التابعة للديوان
            </h1>
            <p class="text-sm text-slate-300">
                استكشف الوحدات الرياضية، الأنشطة المتاحة، وأوقات العمل.
            </p>
        </div>

        <a href="{{ route('home') }}"
           class="inline-flex items-center px-4 py-2 rounded-lg text-sm font-bold text-slate-900 bg-emerald-400 hover:bg-emerald-300 transition">
            ⬅ الصفحة الرئيسية
        </a>
    </div>

    @if($facilities->isEmpty())
        <div class="bg-slate-900/60 border border-slate-700 rounded-2xl p-6 text-center text-sm text-slate-300">
            لا توجد مرافق متاحة حالياً.
        </div>
    @else
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            @foreach($facilities as $facility)
                <a href="{{ route('facilities.show', $facility) }}"
                   class="block bg-slate-900/70 border border-slate-700 hover:border-emerald-400 rounded-2xl p-5 transition group">
                    <div class="flex items-start justify-between gap-3">
                        <div>
                            <h2 class="text-lg font-bold text-white group-hover:text-emerald-400">
                                {{ $facility->name }}
                            </h2>
                            <p class="text-xs text-slate-300 mt-1">
                                {{ $facility->address ?? 'العنوان غير متوفر' }}
                            </p>
                        </div>
                        <span class="text-[11px] px-2 py-1 rounded-full border border-slate-600 text-slate-200">
                            {{ $facility->status === 'available' ? 'متاح' : 'محدود' }}
                        </span>
                    </div>

                    <div class="mt-4 text-xs text-slate-300 space-y-1">
                        <p>
                            عدد المنخرطين: 
                            <span class="font-bold text-emerald-400">
                                {{ $membersCount[$facility->id] ?? 0 }}
                            </span>
                        </p>

                        @if(!empty($facility->work_hours))
                            <p>
                                أوقات العمل: 
                                <span class="font-medium">
                                    {{ is_array($facility->work_hours) ? implode(' - ', $facility->work_hours) : $facility->work_hours }}
                                </span>
                            </p>
                        @endif
                    </div>

                    <div class="mt-4 text-[11px] text-slate-400 flex items-center justify-between">
                        <span>عرض تفاصيل المرفق والأنشطة</span>
                        <span class="text-emerald-400">←</span>
                    </div>
                </a>
            @endforeach
        </div>
    @endif
</div>

</body>
</html>
