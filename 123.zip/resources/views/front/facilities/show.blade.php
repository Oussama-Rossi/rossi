<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>{{ $facility->name }} - تفاصيل المرفق الرياضي</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700;900&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Tajawal', sans-serif; background-color: #020617; }
    </style>
</head>
<body class="min-h-screen text-white">

<div class="max-w-5xl mx-auto px-4 py-10">
    <div class="flex items-center justify-between mb-6">
        <div>
            <h1 class="text-2xl md:text-3xl font-extrabold text-emerald-400 mb-1">
                {{ $facility->name }}
            </h1>
            <p class="text-sm text-slate-300">
                مرفق رياضي تابع لديوان المركب المتعدد الرياضات.
            </p>
        </div>

        <div class="flex gap-2">
            <a href="{{ route('facilities.index') }}"
               class="inline-flex items-center px-3 py-2 rounded-lg text-xs font-bold text-slate-900 bg-slate-200 hover:bg-slate-100 transition">
                ⬅ كل المرافق
            </a>
            <a href="{{ route('home') }}"
               class="inline-flex items-center px-3 py-2 rounded-lg text-xs font-bold text-slate-900 bg-emerald-400 hover:bg-emerald-300 transition">
                ⬅ الصفحة الرئيسية
            </a>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-5 mb-8">
        <div class="bg-slate-900/80 border border-slate-700 rounded-2xl p-4">
            <div class="text-xs text-slate-400 mb-1">حالة المرفق</div>
            <div class="text-lg font-bold">
                @if($facility->status === 'available')
                    <span class="text-emerald-400">متاح للاستغلال</span>
                @elseif($facility->status === 'closed')
                    <span class="text-red-400">مغلق مؤقتاً</span>
                @else
                    <span class="text-amber-300">محدود</span>
                @endif
            </div>
        </div>

        <div class="bg-slate-900/80 border border-slate-700 rounded-2xl p-4">
            <div class="text-xs text-slate-400 mb-1">عدد المنخرطين</div>
            <div class="text-2xl font-extrabold text-emerald-400">
                {{ $membersCount }}
            </div>
        </div>

        <div class="bg-slate-900/80 border border-slate-700 rounded-2xl p-4">
            <div class="text-xs text-slate-400 mb-1">أوقات العمل</div>
            <div class="text-sm">
                @if(!empty($facility->work_hours))
                    {{ is_array($facility->work_hours) ? implode(' - ', $facility->work_hours) : $facility->work_hours }}
                @else
                    <span class="text-slate-400">لم يتم إدخال أوقات العمل بعد.</span>
                @endif
            </div>
        </div>
    </div>

    <div class="bg-slate-900/80 border border-slate-700 rounded-2xl p-5 mb-6">
        <h2 class="text-lg font-bold mb-2">معلومات المرفق</h2>
        <p class="text-sm text-slate-300 mb-2">
            العنوان:
            <span class="font-semibold text-white">
                {{ $facility->address ?? 'غير متوفر' }}
            </span>
        </p>
        @if(!empty($facility->description))
            <p class="text-sm text-slate-300">
                الوصف:
                <span class="font-semibold text-white">
                    {{ $facility->description }}
                </span>
            </p>
        @endif
    </div>

    <div class="bg-slate-900/80 border border-slate-700 rounded-2xl p-5 mb-6">
        <h2 class="text-lg font-bold mb-3">الأنشطة الرياضية المتاحة</h2>

        @if(!empty($sports))
            <div class="flex flex-wrap gap-2 text-xs">
                @foreach($sports as $sport)
                    <span class="px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-400/60 text-emerald-200">
                        {{ $sport }}
                    </span>
                @endforeach
            </div>
        @else
            <p class="text-sm text-slate-300">
                لم يتم تسجيل الأنشطة الرياضية لهذا المرفق بعد.
            </p>
        @endif
    </div>

    <div class="bg-slate-900/80 border border-slate-700 rounded-2xl p-5">
        <h2 class="text-lg font-bold mb-3">هل ترغب في الانخراط في هذا المرفق؟</h2>
        <p class="text-sm text-slate-300 mb-3">
            يمكنك الانتقال مباشرة إلى استمارة الانخراط واختيار هذا المرفق ضمن خيارات التسجيل.
        </p>
        <a href="{{ route('public.join') }}"
           class="inline-flex items-center px-5 py-2.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-sm font-bold text-slate-900 transition">
            الانتقال إلى استمارة الانخراط
        </a>
    </div>
</div>

</body>
</html>
