<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>لوحة تحكم النادي</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700;900&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Tajawal', sans-serif; }
    </style>
</head>
<body class="bg-slate-950 text-slate-100">

    {{-- Navbar --}}
    <nav class="bg-slate-900/95 border-b border-slate-800 sticky top-0 z-50">
        <div class="w-full lg:max-w-5xl lg:mx-auto px-4 py-2.5 flex items-center justify-between gap-3">
            <div class="flex items-center gap-3">
                <div class="w-11 h-11 sm:w-12 sm:h-12 rounded-full border border-white/10 bg-slate-800 flex items-center justify-center overflow-hidden shrink-0">
                    @if($club->logo)
                        <img src="{{ asset('storage/'.$club->logo) }}" alt="شعار النادي" class="h-full w-full object-cover">
                    @else
                        <span class="text-2xl text-emerald-400">🛡️</span>
                    @endif
                </div>
                <div class="leading-tight">
                    <p class="text-[11px] text-slate-300">لوحة تحكم النادي</p>
                    <p class="text-sm sm:text-base font-bold text-slate-50">
                        {{ $club->name }}
                    </p>
                </div>
            </div>

            <form action="{{ route('public.logout') }}" method="POST" class="shrink-0">
                @csrf
                <button class="px-3 py-2 rounded-lg bg-red-600 hover:bg-red-500 text-white text-xs font-bold shadow flex items-center gap-1 transition">
                    🚪 <span class="hidden sm:inline">خروج</span>
                </button>
            </form>
        </div>
    </nav>

    <main class="pb-8">
        <div class="w-full lg:max-w-5xl lg:mx-auto px-0 lg:px-4 pt-3 lg:pt-6 space-y-3 lg:space-y-6">

            {{-- تنبيه حالة النادي --}}
            @if(!$club->is_active)
                <section class="bg-amber-900/40 border-y lg:border border-amber-500/40 lg:rounded-2xl px-4 py-3 lg:px-5 lg:py-4 shadow-sm flex gap-3">
                    <div class="text-3xl">⚠️</div>
                    <div class="text-xs sm:text-sm">
                        <p class="font-bold text-amber-200 mb-1">الحساب قيد التفعيل</p>
                        <p class="text-amber-100">
                            يرجى إيداع ملف الاعتماد لدى إدارة المركب لتفعيل حساب النادي والبدء في حجز الحصص.
                        </p>
                    </div>
                </section>
            @endif

            {{-- معلومات النادي --}}
            <section class="bg-slate-900 border-b lg:border border-slate-800 lg:rounded-2xl p-5 lg:p-6 shadow-sm">
                <div class="flex flex-col md:flex-row gap-5 md:gap-8 items-start md:items-center">
                    <div class="flex flex-col items-center text-center gap-2 md:w-1/3">
                        <div class="w-24 h-24 rounded-full border border-slate-600 bg-slate-800 flex items-center justify-center overflow-hidden">
                            @if($club->logo)
                                <img src="{{ asset('storage/'.$club->logo) }}" alt="شعار النادي" class="h-full w-full object-cover">
                            @else
                                <span class="text-4xl text-emerald-400">🛡️</span>
                            @endif
                        </div>
                        <div>
                            <h2 class="text-lg font-bold text-slate-50">{{ $club->name }}</h2>
                            <p class="text-[11px] text-slate-400 mt-1">
                                رقم الاعتماد: {{ $club->registration_number }}
                            </p>
                        </div>
                    </div>

                    <div class="flex-1 w-full border-t md:border-t-0 md:border-r border-slate-800 pt-4 md:pt-0 md:pr-6 text-xs sm:text-sm space-y-2.5">
                        <div class="flex justify-between">
                            <span class="text-slate-400">رئيس النادي:</span>
                            <span class="font-bold text-slate-100">{{ $club->president_name }}</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-slate-400">النشاط الرياضي:</span>
                            <span class="font-bold text-emerald-300">{{ $club->sport_activity }}</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-slate-400">حالة الحساب:</span>
                            <span class="font-bold">
                                @if($club->is_active)
                                    <span class="text-emerald-300">مفعل ✅</span>
                                @else
                                    <span class="text-amber-300">قيد التفعيل ⏳</span>
                                @endif
                            </span>
                        </div>
                    </div>
                </div>
            </section>

            {{-- الخدمات / الإجراءات --}}
            <section class="bg-slate-900 border-b lg:border border-slate-800 lg:rounded-2xl p-5 lg:p-6 shadow-sm">
                <h3 class="text-sm sm:text-base font-bold text-slate-100 mb-4">
                    خدمات النادي
                </h3>

                <div class="grid grid-cols-2 gap-3 sm:gap-4">
                    {{-- حجز الحصص --}}
                    <button
                        class="bg-slate-800/60 border border-slate-700 rounded-xl p-4 sm:p-5 text-right hover:border-sky-500 hover:bg-slate-800 transition shadow-sm">
                        <span class="text-3xl block mb-2">📅</span>
                        <h4 class="font-bold text-sm sm:text-base text-slate-50 mb-1">حجز الحصص</h4>
                        <p class="text-[11px] sm:text-xs text-slate-400">
                            طلب توقيت للتدريبات واختيار المرافق المناسبة.
                        </p>
                    </button>

                    {{-- قائمة الرياضيين --}}
                    <button
                        class="bg-slate-800/60 border border-slate-700 rounded-xl p-4 sm:p-5 text-right hover:border-emerald-500 hover:bg-slate-800 transition shadow-sm">
                        <span class="text-3xl block mb-2">👥</span>
                        <h4 class="font-bold text-sm sm:text-base text-slate-50 mb-1">قائمة الرياضيين</h4>
                        <p class="text-[11px] sm:text-xs text-slate-400">
                            إدارة ملفات اللاعبين والانخراطات.
                        </p>
                    </button>
                </div>
            </section>

            <footer class="pt-4 text-center text-[10px] text-slate-500">
                &copy; {{ date('Y') }} ديوان المركب المتعدد الرياضات
            </footer>

        </div>
    </main>

</body>
</html>
