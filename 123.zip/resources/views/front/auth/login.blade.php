<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>تسجيل الدخول - فضاء المنخرط</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap" rel="stylesheet">
    <style>body { font-family: 'Tajawal', sans-serif; }</style>
</head>
<body class="bg-gray-100 h-screen flex items-center justify-center px-4">

    <div class="max-w-md w-full bg-white rounded-2xl shadow-xl overflow-hidden">
        
        <!-- رأس الصفحة -->
        <div class="bg-blue-900 p-6 text-center">
            <div class="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-3 shadow-lg">
                <span class="text-3xl">👤</span>
            </div>
            <h2 class="text-2xl font-bold text-white">فضاء المنخرط</h2>
            <p class="text-blue-200 text-sm">أدخل بياناتك للوصول إلى ملفك</p>
        </div>

        <!-- الفورم -->
        <div class="p-8">
            
            <!-- عرض الأخطاء -->
            @if ($errors->any())
                <div class="bg-red-50 text-red-700 p-3 rounded-lg mb-6 text-sm border border-red-100 text-center font-bold">
                    ⚠️ {{ $errors->first() }}
                </div>
            @endif

            <form action="{{ route('public.login.submit') }}" method="POST">
                @csrf
                
                <div class="mb-5">
                    <label class="block text-gray-700 text-sm font-bold mb-2">البريد الإلكتروني</label>
                    <input type="email" name="email" required 
                        class="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"
                        placeholder="email@example.com">
                </div>
                
                <div class="mb-6">
                    <label class="block text-gray-700 text-sm font-bold mb-2">كلمة المرور</label>
                    <input type="password" name="password" required 
                        class="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition"
                        placeholder="******">
                </div>

                <button type="submit" class="w-full bg-blue-900 text-white font-bold py-3 rounded-xl hover:bg-blue-800 transition shadow-lg transform hover:-translate-y-0.5">
                    دخول
                </button>
            </form>

            <!-- روابط سفلية -->
            <div class="mt-8 pt-6 border-t border-gray-100 text-center">
                <p class="text-gray-600 text-sm mb-2">ليس لديك حساب بعد؟</p>
                <a href="{{ route('public.join') }}" class="text-blue-700 font-bold hover:underline">
                    سجل الآن واحصل على بطاقتك 🚀
                </a>
            </div>

            <div class="mt-4 text-center">
                 <a href="{{ url('/') }}" class="text-gray-400 text-xs hover:text-gray-600">← العودة للرئيسية</a>
            </div>
        </div>
    </div>

</body>
</html>
