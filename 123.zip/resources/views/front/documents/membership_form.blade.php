<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>استمارة انخراط</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            direction: rtl;
            padding: 15px;
            font-size: 14px;
            line-height: 1.6;
        }
        .header {
            text-align: center;
            border-bottom: 2px solid #000;
            margin-bottom: 15px;
            padding-bottom: 10px;
        }
        .header p { margin: 4px 0; font-size: 13px; }
        .header h1 { margin: 5px 0; font-size: 16px; font-weight: bold; }
        .header h2 { margin: 3px 0; font-size: 15px; font-weight: bold; }
        .file-num { text-align: center; font-weight: bold; margin-bottom: 10px; font-size: 15px; }
        .photo { float: left; width: 90px; height: 110px; border: 1px solid #000; text-align: center; line-height: 110px; margin-left: 15px; font-size: 10px; }
        .info-line { margin-bottom: 10px; font-size: 13px; }
        .label { font-weight: bold; display: inline-block; width: 140px; }
        .section { font-weight: bold; margin-top: 14px; margin-bottom: 8px; text-decoration: underline; font-size: 14px; }
        .sig-box { border: 1px solid #000; padding: 12px; margin-top: 12px; min-height: 110px; }
        .sig-title { font-weight: bold; text-align: center; margin-bottom: 10px; font-size: 13px; }
        .sig-line { border-bottom: 1px solid #000; margin-top: 65px; }
    </style>
</head>
<body>

<div class="header">
    <p>الجمهورية الجزائرية الديمقراطية الشعبية</p>
    <h1>وزارة الرياضة والشباب</h1>
    <h2>ديوان المركب المتعدد الرياضات - ولاية قالمة</h2>
    <p>استمارة انخراط رياضي - 2026/2025</p>
</div>

<div class="file-num">رقم الملف: {{ $member->registration_number }}</div>

<div class="photo">صورة</div>

<div class="section">المعلومات الشخصية:</div>
<div class="info-line"><span class="label">الاسم واللقب:</span> {{ $member->first_name }} {{ $member->last_name }}</div>
<div class="info-line"><span class="label">تاريخ الميلاد:</span> {{ $member->birth_date->format('Y/m/d') }}</div>
<div class="info-line"><span class="label">مكان الميلاد:</span> {{ $member->birth_place }}</div>
<div class="info-line"><span class="label">الجنس:</span> {{ $member->gender == 'male' ? 'ذكر' : 'أنثى' }}</div>
<div class="info-line"><span class="label">العنوان:</span> {{ $member->address }}</div>
<div class="info-line"><span class="label">الهاتف:</span> {{ $member->phone }}</div>
<div class="info-line"><span class="label">الإيميل:</span> {{ $member->email ?? $member->user->email ?? '---' }}</div>

<div class="section">النشاط الرياضي:</div>
<div class="info-line"><span class="label">المرفق:</span> {{ $member->facility->name }}</div>
<div class="info-line"><span class="label">الرياضة:</span> {{ $member->sport_type }}</div>
<div class="info-line"><span class="label">التوقيت:</span> {{ $member->time_slot }}</div>

<div class="sig-box">
    <div class="sig-title">إمضاء المعني / الولي</div>
    <p>أصرح بصحة المعلومات وأتعهد باحترام لائحة المركب</p>
    <div class="sig-line"></div>
</div>

<div class="sig-box">
    <div class="sig-title">مصادقة الطبيب</div>
    <p>أشهد أن المعني مؤهل طبياً لممارسة الرياضة</p>
    <div class="sig-line"></div>
</div>

<div class="sig-box">
    <div class="sig-title">توقيع الإدارة</div>
    <p>التاريخ: .............. رقم الوصل: .............. القرار: ☐ مقبول ☐ مرفوض</p>
    <div class="sig-line"></div>
</div>

</body>
</html>
