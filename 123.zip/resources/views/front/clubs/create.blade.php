<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>تسجيل نادي / جمعية</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">

<div class="min-h-screen flex items-center justify-center px-4">
    <div class="bg-white rounded-2xl shadow-lg p-8 max-w-xl w-full">
        <h1 class="text-2xl font-bold mb-6 text-center text-blue-900">
            طلب تسجيل نادي / جمعية
        </h1>

        <form action="{{ route('public.clubs.store') }}" method="POST" class="space-y-4">
            @csrf

            <div>
                <label class="block mb-1 text-sm font-bold text-gray-700">اسم النادي</label>
                <input type="text" name="name" required
                       class="w-full border rounded-lg px-3 py-2">
            </div>

            <div>
                <label class="block mb-1 text-sm font-bold text-gray-700">اسم رئيس النادي</label>
                <input type="text" name="president_name" required
                       class="w-full border rounded-lg px-3 py-2">
            </div>

            <div>
                <label class="block mb-1 text-sm font-bold text-gray-700">الهاتف</label>
                <input type="text" name="phone"
                       class="w-full border rounded-lg px-3 py-2">
            </div>

            <div>
                <label class="block mb-1 text-sm font-bold text-gray-700">النشاط الرئيسي</label>
                <input type="text" name="sport_activity"
                       class="w-full border rounded-lg px-3 py-2">
            </div>

            {{-- هنا اختيار الوحدة --}}
            <div>
                <label for="facility_id" class="block mb-1 text-sm font-bold text-gray-700">
                    اختر الوحدة الرياضية
                </label>
                <select name="facility_id" id="facility_id" required
                        class="w-full border rounded-lg px-3 py-2">
                    <option value="">اختر الوحدة...</option>
                    @foreach($facilities as $facility)
                        <option value="{{ $facility->id }}">{{ $facility->name }}</option>
                    @endforeach
                </select>
            </div>

            <button type="submit"
                    class="w-full bg-blue-900 text-white py-3 rounded-lg font-bold hover:bg-blue-800">
                إرسال الطلب
            </button>
        </form>
    </div>
</div>

</body>
</html>
