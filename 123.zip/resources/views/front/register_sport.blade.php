<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>التسجيل في الرياضات</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700&display=swap" rel="stylesheet">
    <style>body { font-family: 'Tajawal', sans-serif; }</style>
</head>
<body class="bg-gray-50 py-10">

    <div class="max-w-4xl mx-auto px-4">
        <h1 class="text-3xl font-bold text-center mb-8 text-blue-900">التسجيل في الأنشطة الرياضية</h1>

        <!-- صندوق التنبيهات (مقتبس من ورقلة) -->
        <div class="bg-yellow-50 border-r-4 border-yellow-500 p-6 rounded-lg shadow-sm mb-8">
            <div class="flex items-start">
                <div class="text-3xl ml-4">📢</div>
                <div>
                    <h3 class="text-lg font-bold text-yellow-800 mb-2">تنبيهات هامة قبل التسجيل:</h3>
                    <ul class="list-disc list-inside text-yellow-700 space-y-1 text-sm">
                        <li>يجب ملء المعلومات بعناية ومصداقية.</li>
                        <li>يتكون الملف من: استمارة طبية، صورة شمسية، نسخة من بطاقة التعريف.</li>
                        <li><strong>للقصر:</strong> يجب إرفاق تصريح أبوي وشهادة ميلاد.</li>
                        <li>ملفات السباحة تدفع في الإدارة، والرياضات الأخرى في القاعات.</li>
                        <li>آخر أجل لتسجيلات السباحة هو <strong>30 أكتوبر 2025</strong>.</li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- استمارة التسجيل -->
        <div class="bg-white rounded-xl shadow-lg p-8">
            <form action="{{ route('public.register.store') }}" method="POST" enctype="multipart/form-data">
                @csrf
                
                <!-- المعلومات الشخصية -->
                <h3 class="text-xl font-bold mb-4 border-b pb-2 text-gray-700">1. المعلومات الشخصية</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-1">الاسم</label>
                        <input type="text" name="first_name" required class="w-full border rounded p-2">
                    </div>
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-1">اللقب</label>
                        <input type="text" name="last_name" required class="w-full border rounded p-2">
                    </div>
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-1">تاريخ الميلاد</label>
                        <input type="date" name="birth_date" required class="w-full border rounded p-2">
                    </div>
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-1">مكان الميلاد</label>
                        <input type="text" name="birth_place" required class="w-full border rounded p-2">
                    </div>
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-1">الجنس</label>
                        <select name="gender" class="w-full border rounded p-2 bg-white">
                            <option value="male">ذكر</option>
                            <option value="female">أنثى</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-bold text-gray-700 mb-1">رقم الهاتف</label>
                        <input type="tel" name="phone" required class="w-full border rounded p-2">
                    </div>
                </div>

                <!-- اختيار الرياضة -->
                <h3 class="text-xl font-bold mb-4 border-b pb-2 text-gray-700">2. الرياضة المطلوبة</h3>
                <div class="mb-6">
                    <label class="block text-sm font-bold text-gray-700 mb-1">النشاط الرياضي</label>
                    <select name="sport_type" class="w-full border rounded p-2 bg-white">
                        <option value="swimming">السباحة (مسبح شبه أولمبي)</option>
                        <option value="karate">كاراتيه دو</option>
                        <option value="football">كرة القدم (مدرسة)</option>
                        <option value="fitness">لياقة بدنية (Aerobic)</option>
                    </select>
                </div>

                <!-- رفع الوثائق -->
                <h3 class="text-xl font-bold mb-4 border-b pb-2 text-gray-700">3. الوثائق المرفقة (صور أو PDF)</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                    <div class="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:bg-gray-50 transition">
                        <label class="cursor-pointer block">
                            <span class="text-3xl block mb-2">📷</span>
                            <span class="font-bold text-sm block">الصورة الشمسية</span>
                            <input type="file" name="doc_photo" class="hidden">
                        </label>
                    </div>
                    <div class="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:bg-gray-50 transition">
                        <label class="cursor-pointer block">
                            <span class="text-3xl block mb-2">🩺</span>
                            <span class="font-bold text-sm block">الشهادة الطبية (إجبارية)</span>
                            <input type="file" name="doc_medical" required class="hidden">
                        </label>
                    </div>
                </div>

                <button type="submit" class="w-full bg-blue-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-blue-700 transition shadow-lg">
                    تأكيد التسجيل المبدئي
                </button>
            </form>
        </div>
    </div>

</body>
</html>
