<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>ملفي الشخصي - فضاء المنخرط</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> {{-- هام جداً للموبايل --}}
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700;900&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Tajawal', sans-serif; }
    </style>
</head>
<body class="bg-slate-950 text-slate-100">

    {{-- Navbar --}}
    <nav class="bg-slate-900/95 border-b border-slate-800 sticky top-0 z-50">
        <div class="w-full lg:max-w-4xl lg:mx-auto px-4 py-2.5 flex items-center justify-between gap-3">
            {{-- Logo + عنوان --}}
            <div class="flex items-center gap-3">
                <div class="w-12 h-12 sm:w-14 sm:h-14 rounded-full border border-white/10 bg-slate-800 flex items-center justify-center overflow-hidden shrink-0">
                    @if(file_exists(public_path('storage/logo.png')))
                        <img src="{{ asset('storage/logo.png') }}" alt="شعار الديوان"
                             class="h-full w-full object-contain">
                    @else
                        <span class="text-2xl sm:text-3xl text-blue-400">🏟️</span>
                    @endif
                </div>
                <div class="flex flex-col justify-center">
                    <h1 class="text-xs sm:text-sm font-extrabold leading-tight text-slate-100">
                        ديوان المركب المتعدد الرياضات
                    </h1>
                    <p class="text-[10px] text-slate-400">
                        فضاء المنخرط
                    </p>
                </div>
            </div>

            <form action="{{ route('public.logout') }}" method="POST" class="shrink-0">
                @csrf
                <button class="px-3 py-2 rounded-lg bg-red-600 hover:bg-red-500 text-white text-xs font-bold shadow flex items-center gap-1 transition">
                    🚪 <span class="hidden sm:inline">خروج</span>
                </button>
            </form>
        </div>
    </nav>

    <main class="pb-8">
        {{-- الحاوية: عرض كامل على الموبايل (px-0)، ومحصورة على الحاسوب (lg:px-4) --}}
        <div class="w-full lg:max-w-4xl lg:mx-auto px-0 lg:px-4 lg:py-6 space-y-1 lg:space-y-6">

            {{-- ترحيب --}}
            <section class="bg-slate-900 border-b lg:border border-slate-800 lg:rounded-2xl p-5 lg:p-6 flex flex-col sm:flex-row items-start sm:items-center gap-4 shadow-sm">
                <div class="flex items-center gap-3 w-full">
                    <div class="w-12 h-12 rounded-xl bg-slate-800 flex items-center justify-center shrink-0 text-2xl">
                        👤
                    </div>
                    <div>
                        <h1 class="text-lg font-bold text-slate-50">مرحباً، {{ Auth::user()->name }}</h1>
                        <p class="text-xs text-slate-400">حالة ملف الانخراط الخاص بك</p>
                    </div>
                </div>

                <div class="w-full sm:w-auto mt-2 sm:mt-0">
                    @if($member && $member->status == 'approved')
                        <div class="w-full sm:w-auto bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 px-4 py-2 rounded-lg text-xs font-bold text-center">
                            ✅ ملف مفعل
                        </div>
                    @elseif($member && $member->status == 'rejected')
                        <div class="w-full sm:w-auto bg-red-500/10 border border-red-500/30 text-red-400 px-4 py-2 rounded-lg text-xs font-bold text-center">
                            ❌ ملف مرفوض
                        </div>
                    @else
                        <div class="w-full sm:w-auto bg-amber-500/10 border border-amber-500/30 text-amber-400 px-4 py-2 rounded-lg text-xs font-bold text-center">
                            ⏳ قيد الدراسة
                        </div>
                    @endif
                </div>
            </section>

            @if($member)
                {{-- تفاصيل الملف --}}
                <section class="bg-slate-900 border-b lg:border border-slate-800 lg:rounded-2xl overflow-hidden shadow-sm">
                    <div class="bg-slate-800/50 px-5 py-3 border-b border-slate-800 flex justify-between items-center">
                        <h2 class="font-bold text-sm text-slate-200">بيانات الانخراط</h2>
                        <span class="text-[10px] bg-sky-500/10 text-sky-400 px-2 py-1 rounded border border-sky-500/20 font-mono">
                            2025 / 2026
                        </span>
                    </div>

                    <div class="p-5 space-y-4 text-sm text-slate-300">
                        <div class="flex justify-between border-b border-slate-800 pb-2">
                            <span class="text-slate-500">رقم الملف</span>
                            <span class="font-mono font-bold text-lg text-white">{{ $member->registration_number }}</span>
                        </div>
                        <div class="flex justify-between border-b border-slate-800 pb-2">
                            <span class="text-slate-500">المرفق</span>
                            <span class="font-bold text-right max-w-[60%] text-white">{{ $member->facility->name }}</span>
                        </div>
                        <div class="flex justify-between border-b border-slate-800 pb-2">
                            <span class="text-slate-500">الرياضة</span>
                            <span class="font-bold text-sky-400">{{ $member->sport_type }}</span>
                        </div>
                        <div class="flex justify-between border-b border-slate-800 pb-2">
                            <span class="text-slate-500">التوقيت</span>
                            <span class="font-bold text-right max-w-[60%] text-white">{{ $member->time_slot }}</span>
                        </div>
                        <div class="flex justify-between pt-1">
                            <span class="text-slate-500">التاريخ</span>
                            <span class="font-bold text-white">{{ $member->created_at->format('Y/m/d') }}</span>
                        </div>
                    </div>

                    @if($member->status == 'rejected')
                        <div class="mx-5 mb-5 bg-red-950/30 border border-red-500/30 p-3 rounded-lg text-xs text-red-200">
                            <strong class="block mb-1 text-red-400">سبب الرفض:</strong>
                            {{ $member->rejection_reason ?? 'يرجى مراجعة الإدارة.' }}
                        </div>
                    @endif
                </section>

                {{-- أزرار الإجراءات --}}
                <section class="bg-slate-900 border-b lg:border border-slate-800 lg:rounded-2xl p-5 space-y-4 shadow-sm">
                    
                    {{-- استمارة --}}
                    <div class="bg-slate-800/40 rounded-xl p-4 border border-slate-800">
                        <div class="flex items-center gap-3 mb-3">
                            <div class="w-10 h-10 rounded-lg bg-sky-500/10 text-sky-400 flex items-center justify-center text-xl border border-sky-500/20">📄</div>
                            <div>
                                <h3 class="font-bold text-sm text-slate-200">استمارة التسجيل</h3>
                                <p class="text-[11px] text-slate-500">للطباعة والمصادقة</p>
                            </div>
                        </div>
                        <a href="{{ route('members.print-form', $member) }}" target="_blank" class="block w-full bg-slate-100 hover:bg-white text-slate-900 text-center py-3 rounded-lg font-bold text-sm transition">
                            طباعة الاستمارة 🖨️
                        </a>
                    </div>

                    {{-- بطاقة --}}
                    <div class="bg-slate-800/40 rounded-xl p-4 border border-slate-800">
                        <div class="flex items-center gap-3 mb-3">
                            <div class="w-10 h-10 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center text-xl border border-emerald-500/20">🆔</div>
                            <div>
                                <h3 class="font-bold text-sm text-slate-200">بطاقة المنخرط</h3>
                                <p class="text-[11px] text-slate-500">تتاح بعد القبول</p>
                            </div>
                        </div>
                        <button class="block w-full bg-emerald-600 text-white text-center py-3 rounded-lg font-bold text-sm opacity-50 cursor-not-allowed">
                            تحميل البطاقة
                        </button>
                    </div>
                </section>

            @else
                {{-- لا يوجد ملف --}}
                <section class="bg-slate-900 border lg:border border-slate-800 lg:rounded-2xl p-8 text-center">
                    <div class="text-5xl mb-4">📂</div>
                    <h2 class="text-lg font-bold mb-2 text-slate-100">لا يوجد ملف انخراط</h2>
                    <p class="text-sm text-slate-400 mb-6">ابدأ التسجيل الآن للانضمام للمركب.</p>
                    <a href="{{ route('public.join') }}" class="inline-block bg-sky-600 hover:bg-sky-500 text-white px-8 py-3 rounded-xl font-bold shadow-lg transition">
                        بدء التسجيل 🚀
                    </a>
                </section>
            @endif

            <footer class="py-6 text-center text-[10px] text-slate-600">
                &copy; {{ date('Y') }} ديوان المركب المتعدد الرياضات
            </footer>

        </div>
    </main>

</body>
</html>
