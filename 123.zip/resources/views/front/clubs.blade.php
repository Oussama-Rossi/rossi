@extends('layouts.app_front')

@section('title', 'دليل النوادي الرياضية')

@section('content')
    <div class="max-w-7xl mx-auto px-4 py-10 md:py-12">

        {{-- أزرار أعلى الصفحة --}}
        <div class="flex flex-col md:flex-row justify-center gap-3 mb-8">
            <a href="{{ route('login') }}"
               class="inline-flex items-center justify-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-xl font-bold text-sm hover:bg-blue-500 transition shadow">
                🔑 تسجيل الدخول (النوادي)
            </a>
            <a href="{{ route('public.clubs.create') }}"
               class="inline-flex items-center justify-center gap-2 bg-slate-900 text-emerald-400 px-6 py-3 rounded-xl font-bold text-sm border border-emerald-400 hover:bg-slate-800 transition">
                ➕ تسجيل نادي / جمعية جديدة
            </a>
        </div>

        @if($clubs->count() > 0)
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
                @foreach($clubs as $club)
                    <div class="bg-slate-900/90 rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition duration-300 border border-slate-700 flex flex-col h-full card-hover">

                        {{-- شعار النادي --}}
                        <div class="h-44 md:h-48 bg-slate-800 flex items-center justify-center relative">
                            @if($club->logo)
                                <img src="{{ asset('storage/' . $club->logo) }}" alt="{{ $club->name }}" class="h-28 md:h-32 object-contain">
                            @else
                                <span class="text-6xl">🛡️</span>
                            @endif

                            {{-- شارة الحالة --}}
                            <div class="absolute top-4 left-4">
                                @if($club->is_active)
                                    <span class="bg-emerald-100 text-emerald-800 text-[11px] px-3 py-1 rounded-full font-bold border border-emerald-300">
                                        نشط حالياً
                                    </span>
                                @else
                                    <span class="bg-amber-100 text-amber-800 text-[11px] px-3 py-1 rounded-full font-bold border border-amber-300">
                                        في انتظار الموافقة
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="p-5 md:p-6 flex-1 flex flex-col">
                            <div class="mb-4">
                                <h3 class="text-lg md:text-xl font-bold text-white mb-1">
                                    {{ $club->name }}
                                </h3>
                                <p class="text-xs md:text-sm text-emerald-300 font-bold">
                                    {{ $club->sport_activity }}
                                </p>
                            </div>

                            <div class="space-y-3 text-xs md:text-sm text-gray-200 mb-5 flex-1">
                                <div class="flex items-center gap-2">
                                    <span>👤</span>
                                    <span>الرئيس: <strong>{{ $club->president_name }}</strong></span>
                                </div>
                                <div class="flex items-center gap-2">
                                    <span>📍</span>
                                    <span>{{ $club->address ?? 'العنوان غير متوفر' }}</span>
                                </div>
                                <div class="flex items-center gap-2">
                                    <span>📞</span>
                                    <span dir="ltr">{{ $club->phone }}</span>
                                </div>
                            </div>

                            <div class="pt-4 border-t border-slate-700 mt-auto">
                                @if($club->email)
                                    <a href="mailto:{{ $club->email }}"
                                       class="block w-full text-center bg-slate-800 text-gray-100 py-2 rounded-lg font-bold hover:bg-slate-700 transition text-xs md:text-sm border border-slate-600">
                                        مراسلة النادي 📧
                                    </a>
                                @else
                                    <button disabled
                                            class="block w-full text-center bg-slate-800 text-slate-500 py-2 rounded-lg font-bold text-xs md:text-sm cursor-not-allowed border border-slate-700">
                                        غير متاح إلكترونياً
                                    </button>
                                @endif
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        @else
            <div class="text-center py-16 md:py-20 bg-slate-900/80 rounded-3xl border border-dashed border-slate-600">
                <span class="text-6xl block mb-4 opacity-60">📭</span>
                <h3 class="text-lg md:text-xl font-bold text-gray-200">
                    لا توجد نوادي مسجلة حالياً
                </h3>
                <p class="text-gray-400 mt-2 text-sm">
                    يرجى العودة لاحقاً.
                </p>
            </div>
        @endif

    </div>
@endsection
