<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>استمارة تسجيل {{ $member->full_name ?? '' }}</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        @page {
            size: A4;
            margin: 0;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            padding: 20px;
        }

        @media print {
            body {
                background-color: white;
                padding: 0;
            }

            .print-button,
            .no-print {
                display: none !important;
            }

            .container {
                box-shadow: none;
                margin: 0;
                width: 210mm;
                height: 297mm;
                padding: 18mm;
            }
        }

        .container {
            max-width: 210mm;
            height: 297mm;
            background: white;
            margin: 0 auto;
            padding: 28px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            position: relative;
            overflow: hidden;
        }

        /* خلفية فارغة، فقط لضبط الطبقات */
        .background-decoration {
            position: absolute;
            inset: 0;
            pointer-events: none;
            z-index: 0;
        }

        /* الشعار كـ watermark */
        .watermark-logo {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            opacity: 0.08;
            width: 55%;
            height: auto;
            pointer-events: none;
            z-index: 0;
        }

        .content {
            position: relative;
            z-index: 1;
        }

        .header {
            text-align: center;
            margin-bottom: 18px;
            border-bottom: 3px solid #0088cc;
            padding-bottom: 12px;
        }

        .header-title {
            color: #0066cc;
            font-size: 25px;
            font-weight: bold;
            margin-bottom: 4px;
        }

        .header-subtitle {
            color: #0088cc;
            font-size: 15px;
            margin-bottom: 3px;
        }

        .header-description {
            color: #666;
            font-size: 13px;
            font-style: italic;
        }

        .form-section {
            margin-bottom: 14px;
        }

        .section-title {
            background-color: #e8f4f8;
            border-right: 4px solid #0088cc;
            padding: 8px 12px;
            font-weight: bold;
            color: #0066cc;
            font-size: 13px;
            margin-bottom: 10px;
            border-radius: 2px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 14px;
            margin-bottom: 10px;
        }

        .form-row.full {
            grid-template-columns: 1fr;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-label {
            font-weight: bold;
            font-size: 12px;
            color: #333;
            margin-bottom: 4px;
        }

        .form-input {
            border: none;
            border-bottom: 1px solid #0088cc;
            padding: 6px 4px;
            font-size: 12px;
            background-color: transparent;
        }

        .box-section {
            border: 2px solid #0088cc;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 14px;
            background-color: #f9fbfd;
        }

        .box-title {
            font-weight: bold;
            color: #0066cc;
            font-size: 14px;
            margin-bottom: 10px;
            padding-bottom: 8px;
            border-bottom: 1px solid #ccc;
        }

        .medical-box {
            font-size: 12px;
            line-height: 1.8;
            color: #333;
        }

        .signature-section {
            margin-top: 15px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 22px;
            font-size: 11px;
            margin-bottom: 50mm;
        }

        .signature-line {
            text-align: center;
            padding-top: 30px;
            border-top: 1px solid #333;
        }

        .signature-label {
            font-weight: bold;
            margin-top: 5px;
        }

        .footer-info {
            font-size: 10px;
            color: #666;
            margin-top: 8px;
            padding-top: 8px;
            border-top: 1px solid #ddd;
            text-align: center;
        }

        .print-button {
            display: block;
            margin: 20px auto;
            padding: 12px 30px;
            background-color: #0088cc;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 14px;
            cursor: pointer;
            font-weight: bold;
        }

        .print-button:hover {
            background-color: #0066aa;
        }

        .file-number {
            text-align: left;
            font-size: 15px;
            color: #666;
            margin-bottom: 10px;
        }
.watermark-logo {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    opacity: 0.05; /* شفافية خفيفة */
    width: 70%;    /* جرب بين 40% و70% حسب الشعار */
    height: auto;
    pointer-events: none;
    z-index: 0;
}

.content {
    position: relative;
    z-index: 1;
}



    </style>
</head>
<body>

<button class="print-button" onclick="window.print()">🖨️ اطبع الاستمارة</button>

<div class="container">
    <div class="background-decoration"></div>
    <img src="{{ asset('storage/logo.png') }}" alt="شعار الديوان" class="watermark-logo">

<div class="background-decoration"></div>

{{-- شعار كصورة فوق الخلفية، شفاف --}}
<img src="{{ asset('storage/logo.png') }}"
     alt="شعار الديوان"
     class="watermark-logo">

    <div class="content">
        <div class="file-number">
            رقم الملف: {{ $member->id }}
        </div>

        <div class="header">
            <div class="header-title">ديوان المركب المتعدد الرياضات قالمة</div>
            <div class="header-subtitle">
                {{ $member->facility->name ?? 'الوحدة الرياضية' }}
            </div>
            <div class="header-description">استمارة التسجيل</div>
        </div>

        {{-- البيانات الشخصية --}}
        <div class="form-section">
            <div class="section-title">البيانات الشخصية</div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">الاسم الكامل (اسم ولقب)</label>
                    <div class="form-input">
                        {{ $member->full_name ?? ($member->first_name . ' ' . $member->last_name) }}
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">تاريخ ومكان الميلاد</label>
                    <div class="form-input">
                        {{ optional($member->birth_date)->format('Y-m-d') ?? '' }} - {{ $member->birth_place ?? '' }}
                    </div>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">العنوان</label>
                    <div class="form-input">
                        {{ $member->address ?? '' }}
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">رقم الهاتف</label>
                    <div class="form-input">
                        {{ $member->phone ?? '' }}
                    </div>
                </div>
            </div>
        </div>

        {{-- بيانات ولي الأمر --}}
        <div class="form-section">
            <div class="section-title">بيانات ولي الأمر (في حالة الأطفال)</div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">اسم ولي الأمر</label>
                    <div class="form-input">
                        {{ $member->guardian_name ?? '' }}
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">صلة القرابة</label>
                    <div class="form-input">
                        {{ $member->guardian_relation ?? '' }}
                    </div>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">رقم هاتف ولي الأمر</label>
                    <div class="form-input">
                        {{ $member->guardian_phone ?? '' }}
                    </div>
                </div>
            </div>
        </div>

        {{-- الشهادة الطبية --}}
        <div class="form-section">
            <div class="box-section">
                <div class="box-title">الشهادة الطبية - Certificat Médical</div>
                <div class="medical-box">
                    <p>
                        أنا الطبيب الموقع أدناه، أشهد بأنني فحصت المنخرط/ة:
                        ........................................ بتاريخ .....................
                    </p>
                    <p style="margin-top: 6px;">
                        وأصرح بأن هذا/هذه المنخرط/ة لا يعاني من أي موانع طبية
                        لممارسة رياضة {{ $member->sport_type ?? '........................' }}.
                    </p>
                    <p style="margin-top: 8px; text-align: center;">
                        التاريخ: ........................ التوقيع والختم: ........................
                    </p>
                </div>
            </div>
        </div>

        {{-- تصريح بالموافقة --}}
        <div class="form-section">
            <div class="box-section">
                <div class="box-title">تصريح بالموافقة - Autorisation</div>
                <div style="font-size: 12px; line-height: 1.9; color: #333;">
                    <p>
                        أنا المسؤول القانوني أصرح بموافقتي على ممارسة المنخرط/ة
                        لرياضة {{ $member->sport_type ?? '........................' }}
                        مع ديوان المركب المتعدد الرياضات قالمة.
                    </p>
                    <p style="margin-top: 8px;">
                        التاريخ: ........................ التوقيع: ........................
                    </p>
                </div>
            </div>
        </div>

        <div class="signature-section">
            <div class="signature-line">
                <div class="signature-label">توقيع المسجل</div>
            </div>
            <div class="signature-line">
                <div class="signature-label">توقيع رئيس الوحدة</div>
            </div>
        </div>

        <div class="footer-info">
            ملاحظة: جميع المعلومات المدرجة في هذه الاستمارة سرية وتستخدم فقط لأغراض التسجيل في الديوان.
        </div>
    </div>
</div>

</body>
</html>
