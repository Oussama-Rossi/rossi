<!doctype html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'DigiTicket DZ - المنصة الرياضية')</title>

    <script src="/_sdk/data_sdk.js"></script>
    <script src="/_sdk/element_sdk.js"></script>

    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>

    <style>
        body {
            box-sizing: border-box;
            font-family: 'Cairo', sans-serif;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        .gradient-bg {
            background: linear-gradient(135deg, #000000 0%, #1a1a1a 100%);
        }

        .card-hover {
            transition: all 0.3s ease;
        }

        .card-hover:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 40px rgba(255, 255, 255, 0.1);
        }

        .btn-primary {
            background: linear-gradient(135deg, #22c55e 0%, #16a34a 100%);
            transition: all 0.3s ease;
        }

        .btn-primary:hover {
            transform: scale(1.05);
            box-shadow: 0 10px 30px rgba(34, 197, 94, 0.4);
        }

        .ticket-seat {
            transition: all 0.2s ease;
        }

        .ticket-seat:hover {
            transform: scale(1.1);
        }

        .loading-spinner {
            border: 3px solid rgba(255, 255, 255, 0.1);
            border-top: 3px solid #22c55e;
            border-radius: 50%;
            width: 24px;
            height: 24px;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .success-message {
            animation: slideIn 0.5s ease;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .stadium-grid {
            display: grid;
            grid-template-columns: repeat(10, 1fr);
            gap: 8px;
        }

        @media (max-width: 768px) {
            .stadium-grid {
                grid-template-columns: repeat(5, 1fr);
            }
        }

        @view-transition { navigation: auto; }
    </style>

    @stack('head')
</head>
<body class="w-full min-h-full gradient-bg text-white">

    {{-- Navbar عام للموقع --}}
    <nav class="w-full bg-black bg-opacity-50 backdrop-blur-lg border-b border-gray-800 sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 py-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 bg-gradient-to-br from-green-500 to-green-700 rounded-lg flex items-center justify-center">
                        <span class="text-2xl">🎫</span>
                    </div>
                    <h1 id="site-title" class="text-2xl font-bold">
                        DigiTicket DZ
                    </h1>
                </div>

                <div class="flex gap-4">
                    <a href="{{ route('home') }}"
                       class="px-4 py-2 hover:bg-white hover:bg-opacity-10 rounded-lg transition">
                        الرئيسية
                    </a>
                    <a href="{{ route('public.clubs') }}"
                       class="px-4 py-2 hover:bg-white hover:bg-opacity-10 rounded-lg transition">
                        النوادي
                    </a>
                    <a href="#"
                       onclick="window.location.href='{{ route('public.join') }}'"
                       class="px-4 py-2 hover:bg-white hover:bg-opacity-10 rounded-lg transition">
                        الانخراط
                    </a>
                </div>

                <div>
                    @auth
                        <a href="{{ route('public.profile') }}"
                           class="bg-blue-900 text-white px-4 py-2 rounded-full font-bold text-sm hover:bg-blue-800 transition">
                            حسابي
                        </a>
                    @else
                        <a href="{{ route('login') }}"
                           class="bg-blue-900 text-white px-4 py-2 rounded-full font-bold text-sm hover:bg-blue-800 transition">
                            تسجيل الدخول
                        </a>
                    @endauth
                </div>
            </div>
        </div>
    </nav>

    {{-- هنا محتوى كل صفحة --}}
    <main class="min-h-[70vh]">
        @yield('content')
    </main>

    {{-- رسالة نجاح عامة يمكن استخدامها --}}
    <div id="success-message"
         class="fixed top-20 left-1/2 transform -translate-x-1/2 bg-green-600 text-white px-6 py-4 rounded-lg shadow-lg hidden z-50">
        <div class="flex items-center gap-3">
            <span class="text-2xl">✅</span>
            <span class="font-bold">تمت العملية بنجاح</span>
        </div>
    </div>

    {{-- Footer ثابت --}}
    <footer class="w-full bg-black border-t border-gray-800 py-8 px-4 mt-20">
        <div class="max-w-7xl mx-auto text-center">
            <p id="footer-text" class="text-gray-400">
                جميع الحقوق محفوظة © {{ date('Y') }} DigiTicket DZ
            </p>
            <p class="text-sm text-gray-500 mt-2">🇩🇿 صُنع بفخر في الجزائر</p>
        </div>
    </footer>

    @stack('scripts')
</body>
</html>
