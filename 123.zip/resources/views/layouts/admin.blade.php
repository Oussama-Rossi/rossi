<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ديوان المركب المتعدد الرياضات - قالمة- @yield('title')</title>
    
    <!-- الخط العربي -->
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Alpine.js للتفاعلات -->
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

    <style>
        body { font-family: 'Tajawal', sans-serif; }
        [x-cloak] { display: none !important; }
    </style>
</head>
<body class="bg-gray-100 text-gray-800">

    <div x-data="{ sidebarOpen: false }" class="flex h-screen overflow-hidden">
        
        <!-- القائمة الجانبية (Sidebar) -->
        <aside class="flex-shrink-0 w-64 bg-slate-800 text-white transition-all duration-300" 
               :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0 fixed lg:static h-full z-30'">
            
            <div class="h-16 flex items-center justify-center bg-slate-900 shadow-md">
                <h2 class="text-2xl font-bold text-blue-400">DCMS Sports</h2>
            </div>

            <nav class="mt-5 px-2 space-y-1">
                <!-- الرئيسية -->
                <a href="{{ route('dashboard') }}" class="group flex items-center px-2 py-3 text-base font-medium rounded-md {{ request()->routeIs('dashboard') ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-slate-700 hover:text-white' }}">
                    <svg class="ml-3 h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>
                    لوحة القيادة
                </a>

                <!-- الموارد البشرية (تم تفعيل الرابط) -->
                <a href="{{ route('employees.index') }}" class="group flex items-center px-2 py-3 text-base font-medium rounded-md {{ request()->routeIs('employees.*') ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-slate-700 hover:text-white' }}">
                    <svg class="ml-3 h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>
                    الموظفين (HR)
                </a>

                <!-- الحجوزات (قريباً) -->
                <a href="#" class="group flex items-center px-2 py-3 text-base font-medium rounded-md text-gray-300 hover:bg-slate-700 hover:text-white">
                    <svg class="ml-3 h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                    الحجوزات
                </a>
            </nav>
        </aside>

        <!-- المحتوى الرئيسي -->
        <div class="flex-1 flex flex-col overflow-hidden relative">
            
            <!-- الشريط العلوي -->
            <header class="bg-white shadow-sm z-10">
                <div class="max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8 flex justify-between items-center">
                    <!-- زر القائمة للموبايل -->
                    <button @click="sidebarOpen = !sidebarOpen" class="lg:hidden text-gray-500 focus:outline-none">
                        <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" /></svg>
                    </button>
                    
                    <h1 class="text-xl font-semibold text-gray-800">@yield('header')</h1>

                    <div class="flex items-center">
                        <span class="ml-4 text-sm text-gray-600">مرحباً، {{ auth()->user()->name }}</span>
                        <form method="POST" action="{{ route('logout') }}">
                            @csrf
                            <button type="submit" class="text-sm text-red-600 hover:text-red-800 font-medium">خروج</button>
                        </form>
                    </div>
                </div>
            </header>

            <!-- منطقة المحتوى -->
            <main class="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100 p-6">
                @yield('content')
            </main>
        </div>
        
        <!-- تغطية الخلفية للموبايل -->
        <div x-show="sidebarOpen" @click="sidebarOpen = false" class="fixed inset-0 bg-black opacity-50 z-20 lg:hidden"></div>
    </div>

</body>
</html>
