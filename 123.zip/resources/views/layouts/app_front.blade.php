<!doctype html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>@yield('title', 'المنصة الرياضية')</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    {{-- Tailwind CDN --}}
    <script src="https://cdn.tailwindcss.com"></script>

    {{-- خط عربي مريح --}}
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap" rel="stylesheet">

    <style>
        body {
            box-sizing: border-box;
            font-family: 'Cairo', sans-serif;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        .gradient-bg {
            background: radial-gradient(circle at top, #1f2937 0, #020617 45%, #000000 100%);
        }

        .card-hover {
            transition: all 0.25s ease;
        }

        .card-hover:hover {
            transform: translateY(-6px);
            box-shadow: 0 18px 35px rgba(0, 0, 0, 0.7);
        }
    </style>

    @stack('head')
</head>
<body class="w-full min-h-screen gradient-bg text-white flex flex-col">

    {{-- Navbar --}}
    <nav class="w-full bg-black/60 backdrop-blur border-b border-gray-800 sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 py-2 flex items-center justify-between gap-4">

            {{-- Logo + عنوان --}}
<div class="flex items-center gap-3">
    <div class="w-14 h-14 rounded-full border-white/20 flex items-center justify-center overflow-hidden">
        @if(file_exists(public_path('storage/logo.png')))
            <img src="{{ asset('storage/logo.png') }}" alt="شعار الديوان"
                 class="h-full w-full object-contain block">
        @else
            <span class="text-3xl text-blue-400">🏟️</span>
        @endif
    </div>
    <div class="flex flex-col justify-center">
        <h1 class="text-sm md:text-base font-extrabold leading-tight">
            ديوان المركب المتعدد الرياضات
        </h1>
        <p class="text-[10px] text-gray-400">
            ولاية قالمة
        </p>
    </div>
</div>



            {{-- روابط + أزرار (ديسكتوب) --}}
            <div class="hidden md:flex items-center gap-6 text-sm font-semibold">
                <div class="flex items-center gap-3">
                    <a href="{{ route('home') }}"
                       class="px-3 py-1.5 rounded-lg hover:bg-white/10 transition">
                        الرئيسية
                    </a>
                    <a href="{{ route('home') }}#facilities"
                       class="px-3 py-1.5 rounded-lg hover:bg-white/10 transition">
                        المرافق
                    </a>
                    <a href="{{ route('home') }}#matches"
                       class="px-3 py-1.5 rounded-lg hover:bg-white/10 transition">
                        المباريات
                    </a>
                    <a href="{{ route('public.clubs') }}"
                       class="px-3 py-1.5 rounded-lg hover:bg-white/10 transition">
                        النوادي
                    </a>
                </div>

                <div class="flex items-center gap-2">
                  @auth
    <a href="{{ route('profile.redirect') }}"
       class="px-4 py-2 rounded-full bg-blue-600 hover:bg-blue-500 text-xs font-bold transition">
        حسابي
    </a>
@else
    <a href="{{ route('login') }}"
       class="px-4 py-2 rounded-full bg-emerald-500 hover:bg-emerald-400 text-xs font-bold transition">
        تسجيل الدخول
    </a>
@endauth

                </div>
            </div>

            {{-- زر موبايل --}}
            <button id="mobile-menu-toggle"
                    class="md:hidden inline-flex items-center justify-center w-9 h-9 rounded-lg border border-gray-700 hover:bg-white/10 transition">
                <svg xmlns="http://www.w3.org/2000/svg"
                     class="w-5 h-5"
                     fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8"
                          d="M4 6h16M4 12h16M4 18h16"/>
                </svg>
            </button>
        </div>

        {{-- Mobile menu --}}
        <div id="mobile-menu"
             class="md:hidden hidden border-t border-gray-800 bg-black/80 backdrop-blur">
            <div class="px-4 py-3 space-y-2 text-sm font-semibold">
                <a href="{{ route('home') }}"
                   class="block px-3 py-2 rounded-lg hover:bg-white/10">
                    الرئيسية
                </a>
                <a href="{{ route('home') }}#facilities"
                   class="block px-3 py-2 rounded-lg hover:bg-white/10">
                    المرافق
                </a>
                <a href="{{ route('home') }}#matches"
                   class="block px-3 py-2 rounded-lg hover:bg-white/10">
                    المباريات
                </a>
                <a href="{{ route('public.clubs') }}"
                   class="block px-3 py-2 rounded-lg hover:bg-white/10">
                    النوادي
                </a>

                <div class="pt-2 border-t border-gray-800 mt-2">
                    @auth
                        <a href="{{ route('public.profile') }}"
                           class="block w-full text-center px-3 py-2 rounded-full bg-blue-600 hover:bg-blue-500">
                            حسابي
                        </a>
                    @else
                        <a href="{{ route('login') }}"
                           class="block w-full text-center px-3 py-2 rounded-full bg-emerald-500 hover:bg-emerald-400">
                            تسجيل الدخول
                        </a>
                    @endauth
                </div>
            </div>
        </div>
    </nav>

    {{-- صفحة المحتوى --}}
    <main class="flex-1">
        @yield('content')
    </main>

    {{-- فوتر --}}
    <footer class="w-full border-t border-gray-800 bg-black/80 mt-10">
        <div class="max-w-7xl mx-auto px-4 py-6 text-center text-sm">
            <p class="text-gray-400">
                ديوان المركب المتعدد الرياضات لولاية قالمة &copy; {{ date('Y') }}
            </p>
            <p class="text-xs text-gray-500 mt-1">
                🇩🇿 منصة رقمية لتسهيل الانخراط وحجز التذاكر الرياضية
            </p>
        </div>
    </footer>

    {{-- سكربت صغير لقائمة الموبايل --}}
    <script>
        const btn = document.getElementById('mobile-menu-toggle');
        const menu = document.getElementById('mobile-menu');

        if (btn && menu) {
            btn.addEventListener('click', () => {
                menu.classList.toggle('hidden');
            });
        }
    </script>

    @stack('scripts')
</body>
</html>
