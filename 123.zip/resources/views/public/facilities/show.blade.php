<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>{{ $facility->name }} - المرافق الرياضية</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;700;900&display=swap" rel="stylesheet">
    <style>body { font-family: 'Tajawal', sans-serif; }</style>
</head>
<body class="bg-slate-950 text-slate-100">

    {{-- Navbar بسيطة ترجع للصفحة الرئيسية --}}
    <nav class="bg-slate-900/95 border-b border-slate-800 sticky top-0 z-50">
        <div class="w-full max-w-5xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center">
                    <span class="text-xl">🏟️</span>
                </div>
                <div class="leading-tight">
                    <p class="text-[11px] text-slate-300">المرافق الرياضية</p>
                    <p class="text-sm font-bold text-slate-50">
                        {{ $facility->name }}
                    </p>
                </div>
            </div>

            <a href="{{ route('home') }}"
               class="px-3 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 text-xs font-bold text-white shadow">
                ← الرئيسية
            </a>
        </div>
    </nav>

    <main class="pb-10">
        <div class="w-full max-w-5xl mx-auto px-4 pt-4 space-y-5">

            {{-- معلومات أساسية + صورة رئيسية --}}
            <section class="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-lg">
                <div class="flex flex-col md:flex-row gap-5">
                    <div class="md:w-1/3 flex flex-col items-center text-center gap-3">
                        @php
                            $mainImage = $facility->images->first();
                        @endphp

                        @if($mainImage)
                            <img src="{{ asset('storage/'.$mainImage->path) }}"
                                 alt="{{ $facility->name }}"
                                 class="w-40 h-40 rounded-2xl object-cover border border-slate-700">
                        @else
                            <div class="w-40 h-40 rounded-2xl bg-slate-800 flex items-center justify-center text-5xl">
                                🏊
                            </div>
                        @endif

                        <h1 class="text-lg font-bold">{{ $facility->name }}</h1>

                        @if(!empty($facility->address))
                            <p class="text-xs text-slate-400">{{ $facility->address }}</p>
                        @endif
                    </div>

                    <div class="flex-1 text-sm space-y-3">
                        @if(!empty($facility->description))
                            <p class="text-slate-200 leading-relaxed">
                                {{ $facility->description }}
                            </p>
                        @endif

                        {{-- معلومات الاتصال --}}
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-3 border-t border-slate-800 mt-3">
                            @if(!empty($facility->phone))
                                <p><span class="text-slate-400">الهاتف:</span>
                                    <span class="font-bold">{{ $facility->phone }}</span>
                                </p>
                            @endif
                            @if(!empty($facility->email))
                                <p><span class="text-slate-400">البريد:</span>
                                    <span class="font-bold">{{ $facility->email }}</span>
                                </p>
                            @endif
                        </div>

                        {{-- الأنشطة الرياضية --}}
                        @if(!empty($sports) && count($sports))
                            <div class="pt-3 border-t border-slate-800 mt-3">
                                <p class="text-xs font-bold text-slate-300 mb-2">
                                    الأنشطة المتوفرة في هذه الوحدة:
                                </p>
                                <div class="flex flex-wrap gap-2">
                                    @foreach($sports as $sport)
                                        <span class="px-2.5 py-1 rounded-full bg-emerald-600/15 text-emerald-300 text-[11px] border border-emerald-500/40">
                                            {{ trim($sport) }}
                                        </span>
                                    @endforeach
                                </div>
                            </div>
                        @endif
                    </div>
                </div>
            </section>

            {{-- الحصص المبرمجة --}}
            @if($facility->clubTimeSlots->count())
                <section class="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-lg">
                    <h2 class="text-sm sm:text-base font-bold mb-3 text-slate-50">
                        الحصص المبرمجة
                    </h2>
                    <div class="space-y-2 text-xs sm:text-sm">
                        @foreach($facility->clubTimeSlots as $slot)
                            <div class="flex items-center justify-between bg-slate-800/60 border border-slate-700 rounded-xl px-3 py-2">
                                <div>
                                    <p class="font-bold text-slate-100">
                                        {{ $slot->title ?? $slot->sport_type ?? 'حصة رياضية' }}
                                    </p>
                                    <p class="text-[11px] text-slate-400">
                                        {{ $slot->day_of_week ?? '' }}
                                        {{ $slot->time_from ?? '' }}
                                        @if(!empty($slot->time_to))
                                            - {{ $slot->time_to }}
                                        @endif
                                    </p>
                                </div>
                                @if(!empty($slot->coach_name))
                                    <p class="text-[11px] text-slate-300">
                                        المدرب: {{ $slot->coach_name }}
                                    </p>
                                @endif
                            </div>
                        @endforeach
                    </div>
                </section>
            @endif

            {{-- معرض صور --}}
            @if($facility->images->count() > 1)
                <section class="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-lg">
                    <h2 class="text-sm sm:text-base font-bold mb-3 text-slate-50">
                        صور المرفق
                    </h2>
                    <div class="grid grid-cols-2 sm:grid-cols-3 gap-3">
                        @foreach($facility->images->skip(1) as $image)
                            <img src="{{ asset('storage/'.$image->path) }}"
                                 alt="{{ $facility->name }}"
                                 class="w-full h-28 sm:h-32 object-cover rounded-xl border border-slate-700">
                        @endforeach
                    </div>
                </section>
            @endif

        </div>
    </main>

</body>
</html>
