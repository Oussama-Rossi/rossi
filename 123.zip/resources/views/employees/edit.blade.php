@extends('layouts.admin')

@section('title', 'تعديل موظف')
@section('header', 'تعديل بيانات: ' . $employee->first_name . ' ' . $employee->last_name)

@section('content')
<div class="max-w-4xl mx-auto">
    <div class="bg-white rounded-lg shadow overflow-hidden">
        <div class="p-6 border-b border-gray-200">
            <h3 class="text-lg font-medium text-gray-900">تحديث المعلومات</h3>
        </div>

        <form action="{{ route('employees.update', $employee->id) }}" method="POST" class="p-6">
            @csrf
            @method('PUT')
            
            @if($errors->any())
                <div class="mb-4 p-4 bg-red-50 border-r-4 border-red-500 text-red-700">
                    <ul class="list-disc list-inside">
                        @foreach($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- الاسم -->
                <div>
                    <label class="block text-sm font-medium text-gray-700">الاسم</label>
                    <input type="text" name="first_name" value="{{ old('first_name', $employee->first_name) }}" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 border p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">اللقب</label>
                    <input type="text" name="last_name" value="{{ old('last_name', $employee->last_name) }}" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 border p-2">
                </div>

                <!-- الميلاد -->
                <div>
                    <label class="block text-sm font-medium text-gray-700">تاريخ الميلاد</label>
                    <input type="date" name="birth_date" value="{{ old('birth_date', $employee->birth_date->format('Y-m-d')) }}" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 border p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">مكان الميلاد</label>
                    <input type="text" name="birth_place" value="{{ old('birth_place', $employee->birth_place) }}" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 border p-2">
                </div>

                <!-- الجنس (مخفي غالباً لا يتغير، لكن سنعرضه) -->
                <div>
                    <label class="block text-sm font-medium text-gray-700">الجنس</label>
                    <select name="gender" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 border p-2">
                        <option value="male" {{ $employee->gender == 'male' ? 'selected' : '' }}>ذكر</option>
                        <option value="female" {{ $employee->gender == 'female' ? 'selected' : '' }}>أنثى</option>
                    </select>
                </div>
                
                <!-- العنوان -->
                <div>
                    <label class="block text-sm font-medium text-gray-700">العنوان</label>
                    <input type="text" name="address" value="{{ old('address', $employee->address) }}" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 border p-2">
                </div>

                <div class="border-t md:col-span-2 my-2"></div>

                <!-- الوظيفة -->
                <div>
                    <label class="block text-sm font-medium text-gray-700">المسمى الوظيفي</label>
                    <input type="text" name="job_title" value="{{ old('job_title', $employee->job_title) }}" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 border p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">تاريخ التوظيف</label>
                    <input type="date" name="join_date" value="{{ old('join_date', $employee->join_date->format('Y-m-d')) }}" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 border p-2">
                </div>

                <!-- نوع العقد -->
                <div>
                    <label class="block text-sm font-medium text-gray-700">نوع العقد</label>
                    <select name="contract_type" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 border p-2">
                        <option value="CDI" {{ $employee->contract_type == 'CDI' ? 'selected' : '' }}>عقد دائم (CDI)</option>
                        <option value="CDD" {{ $employee->contract_type == 'CDD' ? 'selected' : '' }}>عقد محدد المدة (CDD)</option>
                        <option value="CTA" {{ $employee->contract_type == 'CTA' ? 'selected' : '' }}>عقد CTA</option>
                        <option value="DAIP" {{ $employee->contract_type == 'DAIP' ? 'selected' : '' }}>إدماج مهني (DAIP)</option>
                    </select>
                </div>

                <!-- الحالة (هام جداً في التعديل) -->
                <div>
                    <label class="block text-sm font-medium text-gray-700">حالة الموظف</label>
                    <select name="status" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 border p-2 bg-yellow-50">
                        <option value="active" {{ $employee->status == 'active' ? 'selected' : '' }}>نشط (على رأس العمل)</option>
                        <option value="on_leave" {{ $employee->status == 'on_leave' ? 'selected' : '' }}>في عطلة</option>
                        <option value="terminated" {{ $employee->status == 'terminated' ? 'selected' : '' }}>منتهية مهامه</option>
                        <option value="retired" {{ $employee->status == 'retired' ? 'selected' : '' }}>متقاعد</option>
                    </select>
                </div>
            </div>

            <div class="mt-6 flex items-center justify-end space-x-4 space-x-reverse">
                <a href="{{ route('employees.index') }}" class="bg-gray-200 py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-300 focus:outline-none">إلغاء</a>
                <button type="submit" class="bg-blue-600 py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                    حفظ التغييرات
                </button>
            </div>
        </form>
    </div>
</div>
@endsection
