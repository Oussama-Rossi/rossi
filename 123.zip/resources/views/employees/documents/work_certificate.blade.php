<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>شهادة عمل</title>
    <style>
        body {
            font-family: 'DejaVu Sans', sans-serif;
            text-align: right;
            padding: 30px;
            direction: rtl;
        }
        .header { text-align: center; margin-bottom: 40px; }
        .header h3 { margin: 5px 0; font-size: 16px; font-weight: normal; }
        
        .title { 
            text-align: center; 
            font-size: 24px; 
            font-weight: bold; 
            text-decoration: underline; 
            margin: 30px 0; 
        }

        /* تنسيق الجدول المخفي */
        .info-table {
            width: 100%;
            margin-bottom: 30px;
            border-collapse: collapse;
        }
        .info-table td {
            padding: 8px 5px;
            vertical-align: middle;
            font-size: 18px;
        }
        /* عمود العناوين (يمين) */
        .label-col {
            width: 25%; 
            white-space: nowrap;
        }
        /* عمود البيانات (يسار) */
        .value-col {
            width: 75%;
            font-weight: bold;
        }

        .intro-text, .footer-text {
            font-size: 18px;
            margin-bottom: 20px;
            line-height: 1.6;
        }

        .footer { width: 100%; margin-top: 60px; }
        .date { float: right; width: 40%; text-align: right; font-size: 16px; }
        .signature { float: left; width: 40%; text-align: center; font-weight: bold; font-size: 16px; }
    </style>
</head>
<body>
    <div class="header">
        <h3>{{ $header_1 }}</h3>
        <h3>{{ $header_2 }}</h3>
        <h3>{{ $header_3 }}</h3>
    </div>

    <div class="title">{{ $doc_title }}</div>

    <div class="intro-text">
        {{ $text_intro }}
    </div>

    <!-- الجدول لضمان الترتيب -->
    <table class="info-table">
        <tr>
            <td class="label-col">{{ $text_name }}</td>
            <td class="value-col">{{ $emp_name }}</td>
        </tr>
        <tr>
            <td class="label-col">{{ $text_born }}</td>
            <td class="value-col">
                {{ $emp_birth_date }} &nbsp;&nbsp; {{ $text_at }} &nbsp;&nbsp; {{ $emp_birth_place }}
            </td>
        </tr>
        <tr>
            <td class="label-col">{{ $text_job }}</td>
            <td class="value-col">{{ $emp_job }}</td>
        </tr>
        <tr>
            <td class="label-col">{{ $text_contract_1 }}</td>
            <td class="value-col">
                ({{ $emp_contract }}) 
                {{ $text_contract_2 }} {{ $emp_join_date }}
            </td>
        </tr>
        <tr>
            <td class="label-col"></td> <!-- خانة فارغة -->
            <td class="value-col">{{ $text_contract_3 }}</td>
        </tr>
    </table>

    <div class="footer-text">
        {{ $text_footer }}
    </div>

    <div class="footer">
        <div class="date">
            {{ $location_date }} {{ $current_date }}
        </div>
        <div class="signature">
            {{ $manager_title }}<br><br><br>
            {{ $signature_placeholder }}
        </div>
    </div>
</body>
</html>
