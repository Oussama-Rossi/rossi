@extends('layouts.admin')

@section('title', 'إضافة موظف')
@section('header', 'إضافة موظف جديد')

@section('content')
<div class="max-w-4xl mx-auto">
    <div class="bg-white rounded-lg shadow overflow-hidden">
        <div class="p-6 border-b border-gray-200">
            <h3 class="text-lg font-medium text-gray-900">بيانات الموظف الجديد</h3>
            <p class="mt-1 text-sm text-gray-500">يرجى ملء جميع الحقول المطلوبة بدقة لاستخراج الوثائق لاحقاً.</p>
        </div>

        <form action="{{ route('employees.store') }}" method="POST" class="p-6">
            @csrf
            
            @if($errors->any())
                <div class="mb-4 p-4 bg-red-50 border-r-4 border-red-500 text-red-700">
                    <p class="font-bold">تنبيه!</p>
                    <ul class="list-disc list-inside">
                        @foreach($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- الاسم -->
                <div>
                    <label class="block text-sm font-medium text-gray-700">الاسم</label>
                    <input type="text" name="first_name" value="{{ old('first_name') }}" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 border p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">اللقب</label>
                    <input type="text" name="last_name" value="{{ old('last_name') }}" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 border p-2">
                </div>

                <!-- الميلاد -->
                <div>
                    <label class="block text-sm font-medium text-gray-700">تاريخ الميلاد</label>
                    <input type="date" name="birth_date" value="{{ old('birth_date') }}" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 border p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">مكان الميلاد</label>
                    <input type="text" name="birth_place" value="{{ old('birth_place') }}" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 border p-2">
                </div>

                <!-- الجنس -->
                <div>
                    <label class="block text-sm font-medium text-gray-700">الجنس</label>
                    <select name="gender" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 border p-2">
                        <option value="male">ذكر</option>
                        <option value="female">أنثى</option>
                    </select>
                </div>
                
                <!-- العنوان -->
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700">العنوان الشخصي</label>
                    <input type="text" name="address" value="{{ old('address') }}" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 border p-2">
                </div>

                <div class="border-t md:col-span-2 my-2"></div>

                <!-- الوظيفة -->
                <div>
                    <label class="block text-sm font-medium text-gray-700">المسمى الوظيفي</label>
                    <input type="text" name="job_title" value="{{ old('job_title') }}" placeholder="مثال: عون إدارة، حارس..." required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 border p-2">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">تاريخ التوظيف</label>
                    <input type="date" name="join_date" value="{{ old('join_date') }}" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 border p-2">
                </div>

                <!-- نوع العقد -->
                <div>
                    <label class="block text-sm font-medium text-gray-700">نوع العقد</label>
                    <select name="contract_type" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 border p-2">
                        <option value="CDI">عقد دائم (CDI)</option>
                        <option value="CDD">عقد محدد المدة (CDD)</option>
                        <option value="CTA">عقد CTA</option>
                        <option value="DAIP">إدماج مهني (DAIP)</option>
                    </select>
                </div>

                <!-- الراتب -->
                <div>
                    <label class="block text-sm font-medium text-gray-700">الراتب الأساسي (دج)</label>
                    <input type="number" name="base_salary" value="{{ old('base_salary') }}" step="0.01" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 border p-2">
                </div>

                <!-- الضمان الاجتماعي -->
                <div>
                    <label class="block text-sm font-medium text-gray-700">رقم الضمان الاجتماعي (SSN)</label>
                    <input type="text" name="ssn" value="{{ old('ssn') }}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 border p-2">
                </div>
            </div>

            <div class="mt-6 flex items-center justify-end space-x-4 space-x-reverse">
                <a href="{{ route('employees.index') }}" class="bg-gray-200 py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-300 focus:outline-none">إلغاء</a>
                <button type="submit" class="bg-blue-600 py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                    حفظ البيانات
                </button>
            </div>
        </form>
    </div>
</div>
@endsection
