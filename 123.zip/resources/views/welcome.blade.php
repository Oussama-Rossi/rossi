@extends('layouts.app_front')

@section('title', 'ديوان المركب المتعدد الرياضات - ولاية قالمة')

@section('content')

    {{-- Hero --}}
    <section id="home"
             class="min-h-[70vh] flex items-center justify-center px-4 pt-6 md:pt-10">
        <div class="max-w-5xl mx-auto text-center">
            <p class="text-sm md:text-base text-emerald-400 mb-3">
                المنصة الرقمية الرسمية
            </p>
            <h1 class="text-3xl md:text-5xl lg:text-6xl font-extrabold mb-4 md:mb-6 leading-relaxed md:leading-tight">
                الرياضة أسلوب حياة
            </h1>
            <p class="text-sm md:text-lg text-gray-300 mb-6 md:mb-8 max-w-3xl mx-auto">
                انضم إلينا في أكبر صرح رياضي بالولاية. مسابح، قاعات، وملاعب بمواصفات عالية،
                مع نظام رقمي للانخراط وحجز التذاكر.
            </p>

            <div class="flex flex-col sm:flex-row items-center justify-center gap-3 md:gap-4">
                <a href="{{ route('login') }}"
                   class="w-full sm:w-auto inline-flex justify-center items-center px-7 py-3 md:px-9 md:py-3.5 rounded-full
                          bg-emerald-500 hover:bg-emerald-400 text-sm md:text-base font-bold text-black
                          transition shadow-lg shadow-emerald-500/30">
                    فضاء المنخرطين
                </a>

                <a href="#facilities"
                   class="w-full sm:w-auto inline-flex justify-center items-center px-7 py-3 md:px-9 md:py-3.5 rounded-full
                          border border-gray-500/70 hover:border-white text-sm md:text-base font-bold
                          text-white hover:bg-white/5 transition">
                    اكتشف المرافق
                </a>
            </div>
        </div>
    </section>

    {{-- المباريات القادمة --}}
    <section id="matches" class="py-10 md:py-14 px-4">
        <div class="max-w-7xl mx-auto">
            <div class="flex flex-col md:flex-row md:items-end md:justify-between gap-3 mb-8">
                <div>
                    <h2 class="text-2xl md:text-3xl font-bold mb-1 flex items-center gap-2">
                        <span>⚽</span>
                        <span>المباريات القادمة</span>
                    </h2>
                    <p class="text-gray-300 text-sm">
                        احجز تذكرتك وشجع فريقك المفضل
                    </p>
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                @forelse($matches as $match)
                    <div class="card-hover bg-slate-900/80 rounded-2xl overflow-hidden border border-slate-700">
                        <div class="bg-emerald-600 text-black text-center py-2 text-xs md:text-sm font-bold">
                            {{ $match->championship }}
                        </div>
                        <div class="p-5 md:p-6 text-center">
                            <div class="flex justify-center items-center gap-3 md:gap-4 mb-4">
                                <div class="text-sm md:text-base font-bold text-gray-100 w-1/3">
                                    {{ $match->team_home }}
                                </div>
                                <div class="text-xl md:text-2xl font-black text-red-500">
                                    VS
                                </div>
                                <div class="text-sm md:text-base font-bold text-gray-100 w-1/3">
                                    {{ $match->team_away }}
                                </div>
                            </div>
                            <div class="text-gray-300 text-xs md:text-sm mb-5 flex flex-wrap justify-center gap-3">
                                <span class="flex items-center gap-1">
                                    <span>📅</span>
                                    <span>{{ \Carbon\Carbon::parse($match->match_date)->format('Y/m/d') }}</span>
                                </span>
                                <span class="flex items-center gap-1">
                                    <span>⏰</span>
                                    <span>{{ \Carbon\Carbon::parse($match->match_date)->format('H:i') }}</span>
                                </span>
                            </div>

                            @if($match->is_selling)
                                <button
                                    class="w-full bg-blue-600 hover:bg-blue-500 text-white text-xs md:text-sm py-2.5 md:py-3
                                           rounded-xl font-bold transition">
                                    شراء تذكرة ({{ $match->ticket_price }} دج)
                                </button>
                            @else
                                <button disabled
                                        class="w-full bg-slate-800 text-slate-400 text-xs md:text-sm py-2.5 md:py-3
                                               rounded-xl font-bold cursor-not-allowed">
                                    انتهى البيع
                                </button>
                            @endif
                        </div>
                    </div>
                @empty
                    <div class="col-span-1 md:col-span-3">
                        <div
                            class="text-center py-10 md:py-14 bg-slate-900/70 rounded-2xl border border-dashed border-slate-600">
                            <p class="text-gray-300 text-sm md:text-base">
                                لا توجد مباريات مبرمجة حالياً.
                            </p>
                        </div>
                    </div>
                @endforelse
            </div>
        </div>
    </section>

    {{-- الإحصائيات العامة --}}
    <section class="py-10 md:py-14 bg-slate-950/60">
        <div class="max-w-6xl mx-auto px-4">
            <div class="text-center mb-8">
                <h2 class="text-2xl md:text-3xl font-bold mb-1">
                    إحصائيات الديوان
                </h2>
            </div>

            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 mb-10">
                <div class="bg-slate-900 rounded-2xl shadow-sm p-4 md:p-5 text-center border border-slate-700/70">
                    <div class="text-2xl md:text-3xl mb-1">👥</div>
                    <div class="text-[11px] md:text-xs text-gray-400 mb-1">إجمالي المنخرطين</div>
                    <div class="text-xl md:text-2xl font-extrabold text-emerald-400">
                        {{ $totalMembers }}
                    </div>
                </div>
                <div class="bg-slate-900 rounded-2xl shadow-sm p-4 md:p-5 text-center border border-slate-700/70">
                    <div class="text-2xl md:text-3xl mb-1">👨</div>
                    <div class="text-[11px] md:text-xs text-gray-400 mb-1">عدد الذكور</div>
                    <div class="text-xl md:text-2xl font-extrabold text-blue-400">
                        {{ $maleMembers }}
                    </div>
                </div>
                <div class="bg-slate-900 rounded-2xl shadow-sm p-4 md:p-5 text-center border border-slate-700/70">
                    <div class="text-2xl md:text-3xl mb-1">👩</div>
                    <div class="text-[11px] md:text-xs text-gray-400 mb-1">عدد الإناث</div>
                    <div class="text-xl md:text-2xl font-extrabold text-pink-400">
                        {{ $femaleMembers }}
                    </div>
                </div>
                <div class="bg-slate-900 rounded-2xl shadow-sm p-4 md:p-5 text-center border border-slate-700/70">
                    <div class="text-2xl md:text-3xl mb-1">🏅</div>
                    <div class="text-[11px] md:text-xs text-gray-400 mb-1">النوادي النشطة</div>
                    <div class="text-xl md:text-2xl font-extrabold text-amber-400">
                        {{ $activeClubs }}
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="bg-slate-900 rounded-2xl p-5 md:p-6 border border-slate-700/70">
                    <h3 class="font-bold text-base md:text-lg mb-4 text-gray-100">
                        توزيع المنخرطين حسب الفئة العمرية
                    </h3>
                    <ul class="space-y-2 text-xs md:text-sm text-gray-200">
                        <li class="flex justify-between">
                            <span>أقل من 18 سنة</span>
                            <span class="font-bold">{{ $ageGroups->under_18 ?? 0 }}</span>
                        </li>
                        <li class="flex justify-between">
                            <span>من 18 إلى 29 سنة</span>
                            <span class="font-bold">{{ $ageGroups->age_18_29 ?? 0 }}</span>
                        </li>
                        <li class="flex justify-between">
                            <span>من 30 إلى 45 سنة</span>
                            <span class="font-bold">{{ $ageGroups->age_30_45 ?? 0 }}</span>
                        </li>
                        <li class="flex justify-between">
                            <span>أكثر من 45 سنة</span>
                            <span class="font-bold">{{ $ageGroups->over_45 ?? 0 }}</span>
                        </li>
                    </ul>
                </div>

                <div class="bg-slate-900 rounded-2xl p-5 md:p-6 border border-slate-700/70 space-y-5">
                    <div>
                        <h3 class="font-bold text-base md:text-lg mb-2 text-gray-100">
                            النشاط الأكثر طلباً
                        </h3>
                        @if($topSport)
                            <p class="text-xs md:text-sm text-gray-300 mb-1">النشاط:</p>
                            <p class="text-xl md:text-2xl font-extrabold text-emerald-400">
                                {{ $topSport->sport_type }}
                            </p>
                            <p class="text-[11px] md:text-xs text-gray-400 mt-1">
                                عدد المنخرطين: {{ $topSport->total }}
                            </p>
                        @else
                            <p class="text-gray-400 text-xs md:text-sm">
                                لا توجد بيانات كافية بعد.
                            </p>
                        @endif
                    </div>

                    <div class="border-t border-slate-700 pt-4">
                        <h3 class="font-bold text-base md:text-lg mb-2 text-gray-100">
                            الوحدة الأكثر نشاطاً
                        </h3>
                        @if($topFacility && $topFacility->facility)
                            <p class="text-xs md:text-sm text-gray-300 mb-1">المرفق الرياضي:</p>
                            <p class="text-lg md:text-xl font-extrabold text-blue-400">
                                {{ $topFacility->facility->name }}
                            </p>
                            <p class="text-[11px] md:text-xs text-gray-400 mt-1">
                                عدد المنخرطين: {{ $topFacility->total }}
                            </p>
                        @else
                            <p class="text-gray-400 text-xs md:text-sm">
                                لا توجد بيانات كافية بعد.
                            </p>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </section>

    {{-- المرافق --}}
    <section id="facilities" class="py-10 md:py-14 bg-slate-950/40">
        <div class="max-w-7xl mx-auto px-4">
            <div class="text-center mb-8">
                <h2 class="text-2xl md:text-3xl font-bold mb-1 text-white">
                    مرافقنا الرياضية
                </h2>
                <p class="text-gray-300 text-xs md:text-sm">
                    مجهزة بأحدث التقنيات لراحتكم وسلامتكم
                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                @foreach($facilities as $facility)
                    @php
                        $mainImage = $facility->images->first();
                        $sportsList = is_array($facility->available_sports)
                            ? $facility->available_sports
                            : (empty($facility->available_sports) ? [] : explode(',', $facility->available_sports));
                    @endphp

                    <div class="group relative overflow-hidden rounded-2xl shadow-lg h-60 md:h-64 bg-slate-900/80 border border-slate-700/70">
                        @if($mainImage)
                            <img src="{{ asset('storage/'.$mainImage->path) }}"
                                 class="w-full h-full object-cover transition duration-500 group-hover:scale-110 opacity-85">
                        @else
                            <img src="https://source.unsplash.com/featured/?sport,gym,pool&sig={{ $facility->id }}"
                                 class="w-full h-full object-cover transition duration-500 group-hover:scale-110 opacity-80">
                        @endif

                        <div class="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent"></div>
                        <div class="absolute bottom-0 right-0 p-4 md:p-5 text-white w-full">
                            <h3 class="text-lg md:text-xl font-bold mb-1">
                                {{ $facility->name }}
                            </h3>
                            <div class="flex flex-wrap gap-1.5 md:gap-2 mb-3">
                                @foreach($sportsList as $sport)
                                    @php $sport = trim($sport); @endphp
                                    @if($sport !== '')
                                        <span class="bg-amber-400 text-black text-[10px] md:text-xs px-2 py-0.5 rounded font-bold">
                                            {{ $sport }}
                                        </span>
                                    @endif
                                @endforeach
                            </div>
                            <a href="{{ route('facilities.show', $facility) }}"
                               class="inline-block bg-white text-slate-900 px-4 py-2 rounded-lg text-[11px] md:text-sm font-bold hover:bg-gray-100 transition">
                                تفاصيل الوحدة و المواعيد
                            </a>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>

@endsection
