@extends('layouts.app_front')

@section('title', 'لوحة رئيس النادي')

@section('content')
    <div class="max-w-7xl mx-auto px-4 py-10 md:py-12">

        @if(session('success'))
            <div class="mb-4 px-4 py-3 rounded-lg bg-emerald-600 text-sm">
                {{ session('success') }}
            </div>
        @endif

        @if(session('error'))
            <div class="mb-4 px-4 py-3 rounded-lg bg-red-600 text-sm">
                {{ session('error') }}
            </div>
        @endif

        <h1 class="text-2xl md:text-3xl font-bold mb-6">
            لوحة نادي: {{ $club->name }}
        </h1>

        {{-- كروت سريعة --}}
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <div class="bg-slate-900 rounded-2xl p-4 border border-slate-700">
                <div class="text-sm text-gray-400 mb-1">عدد الحصص المسجلة</div>
                <div class="text-2xl font-extrabold text-emerald-400">
                    {{ $timeSlots->count() }}
                </div>
            </div>
            <div class="bg-slate-900 rounded-2xl p-4 border border-slate-700">
                <div class="text-sm text-gray-400 mb-1">الوحدة الرئيسية</div>
                <div class="text-lg font-bold text-white">
                    {{ optional($club->facility)->name ?? 'غير محددة' }}
                </div>
            </div>
        </div>

        {{-- فورم إضافة حصة جديدة --}}
        <div class="bg-slate-900 rounded-2xl p-5 md:p-6 border border-slate-700 mb-8">
            <h2 class="text-lg md:text-xl font-bold mb-4">
                إضافة حصة جديدة
            </h2>

            <form action="{{ route('club.time-slots.store') }}" method="POST" class="space-y-4">
                @csrf

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs text-gray-300 mb-1">الوحدة الرياضية</label>
                        <select name="facility_id" class="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white" required>
                            <option value="">اختر الوحدة</option>
                            @foreach($facilities as $facility)
                                <option value="{{ $facility->id }}">{{ $facility->name }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div>
                        <label class="block text-xs text-gray-300 mb-1">النشاط</label>
                        <input type="text" name="sport_activity"
                               value="{{ old('sport_activity', $club->sport_activity ?? '') }}"
                               class="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white"
                               required>
                    </div>

                    <div>
                        <label class="block text-xs text-gray-300 mb-1">اليوم</label>
                        <select name="day_of_week" class="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white" required>
                            <option value="">اختر اليوم</option>
                            @foreach(['الأحد','الإثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'] as $day)
                                <option value="{{ $day }}">{{ $day }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="grid grid-cols-2 gap-3">
                        <div>
                            <label class="block text-xs text-gray-300 mb-1">من</label>
                            <input type="time" name="start_time"
                                   class="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white"
                                   required>
                        </div>
                        <div>
                            <label class="block text-xs text-gray-300 mb-1">إلى</label>
                            <input type="time" name="end_time"
                                   class="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white"
                                   required>
                        </div>
                    </div>

                    <div>
                        <label class="block text-xs text-gray-300 mb-1">السعة القصوى (عدد المنخرطين)</label>
                        <input type="number" name="capacity" min="1" max="200"
                               class="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white"
                               required>
                    </div>
                </div>

                <button type="submit"
                        class="mt-2 inline-flex items-center justify-center px-5 py-2.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-sm font-bold text-black">
                    حفظ الحصة
                </button>
            </form>
        </div>

        {{-- جدول الحصص --}}
        <div class="bg-slate-900 rounded-2xl p-5 md:p-6 border border-slate-700">
            <h2 class="text-lg md:text-xl font-bold mb-4">
                الحصص المسجلة
            </h2>

            @if($timeSlots->count())
                <div class="overflow-x-auto text-xs md:text-sm">
                    <table class="min-w-full text-left">
                        <thead>
                        <tr class="text-gray-300 border-b border-slate-700">
                            <th class="py-2">اليوم</th>
                            <th class="py-2">الوقت</th>
                            <th class="py-2">النشاط</th>
                            <th class="py-2">الوحدة</th>
                            <th class="py-2 text-center">المحجوز / السعة</th>
                            <th class="py-2 text-center">الإجراءات</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($timeSlots as $slot)
                            <tr class="border-b border-slate-800">
                                <td class="py-2">{{ $slot->day_of_week }}</td>
                                <td class="py-2">
                                    {{ \Illuminate\Support\Str::of($slot->start_time)->substr(0,5) }}
                                    -
                                    {{ \Illuminate\Support\Str::of($slot->end_time)->substr(0,5) }}
                                </td>
                                <td class="py-2">{{ $slot->sport_activity }}</td>
                                <td class="py-2">{{ optional($slot->facility)->name }}</td>
                                <td class="py-2 text-center">
                                    <span class="{{ $slot->is_full ? 'text-red-400' : 'text-emerald-400' }}">
                                        {{ $slot->current_count }} / {{ $slot->capacity }}
                                    </span>
                                </td>
                                <td class="py-2 text-center">
                                    @if($slot->current_count == 0)
                                        <form action="{{ route('club.time-slots.destroy', $slot) }}" method="POST"
                                              onsubmit="return confirm('حذف هذه الحصة؟');"
                                              class="inline">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="text-xs text-red-400 hover:text-red-300">
                                                حذف
                                            </button>
                                        </form>
                                    @else
                                        <span class="text-xs text-gray-500">
                                            تحتوي منخرطين
                                        </span>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            @else
                <p class="text-gray-400 text-sm">
                    لا توجد حصص مسجلة بعد، يرجى إضافة حصة جديدة.
                </p>
            @endif
        </div>
    </div>
@endsection
