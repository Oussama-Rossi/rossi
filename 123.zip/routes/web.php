<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\PublicAuthController;
use App\Http\Controllers\ClubController;
use App\Http\Controllers\FacilityController;
use App\Http\Controllers\ClubTimeSlotController;
use App\Http\Controllers\ClubMemberController;
use App\Http\Controllers\FacilityPublicController;
use App\Http\Controllers\Admin\SiteSettingsController;
use App\Http\Controllers\MemberPrintController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// 1. الصفحة الرئيسية
Route::get('/', [HomeController::class, 'index'])->name('home');

// 2. نظام التسجيل والانخراط للمواطنين
Route::get('/join', [HomeController::class, 'join'])->name('public.join');
Route::post('/join', [HomeController::class, 'storeJoin'])->name('public.join.store');
Route::get('/download-form/{id}', [HomeController::class, 'downloadForm'])->name('public.download.form');

// 3. دليل النوادي (عرض قائمة النوادي فقط)
Route::get('/clubs', [HomeController::class, 'clubs'])->name('public.clubs');

// 4. تسجيل النوادي (النموذج الجديد + الحفظ)
Route::get('/clubs/new', [ClubController::class, 'create'])->name('public.clubs.create');
Route::post('/clubs', [ClubController::class, 'store'])->name('public.clubs.store');

// لوحة تحكم النادي (محمية)
Route::middleware(['auth'])->get(
    '/club/dashboard',
    [ClubController::class, 'dashboard']
)->name('club.dashboard');

// 5. نظام تسجيل الدخول للمواطنين (فضاء المنخرط)
Route::middleware('guest')->group(function () {
    Route::get('/login', [PublicAuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [PublicAuthController::class, 'login'])->name('public.login.submit');
});

Route::post('/logout', [PublicAuthController::class, 'logout'])->name('public.logout');

// حجز الحصص للنادي
Route::middleware(['auth'])->group(function () {
    Route::get('/club/dashboard/time-slots', [ClubTimeSlotController::class, 'index'])->name('club.time-slots.index');
    Route::post('/club/time-slots', [ClubTimeSlotController::class, 'store'])->name('club.time-slots.store');
    Route::delete('/club/time-slots/{slot}', [ClubTimeSlotController::class, 'destroy'])->name('club.time-slots.destroy');
});

// موافقة/رفض أعضاء النادي
Route::middleware('auth')->group(function () {
    Route::post('/club/members/User/approve', [ClubMemberController::class, 'approve'])
        ->name('club.members.approve');

    Route::post('/club/members/User/reject', [ClubMemberController::class, 'reject'])
        ->name('club.members.reject');
});

// صفحات المرافق العامة
Route::get('/facilities', [FacilityPublicController::class, 'index'])->name('facilities.index');
Route::get('/facilities/{facility}', [FacilityPublicController::class, 'show'])->name('facilities.show');

// بروفيلات وصفحات محمية
Route::middleware('auth')->group(function () {

    // بروفيل المنخرط العادي
    Route::get('/profile', [PublicAuthController::class, 'profile'])->name('public.profile');

    // بروفيل خاص برئيس النادي
    Route::get('/club/profile', [ClubController::class, 'profile'])->name('club.profile');

    // إعدادات الموقع (الأدمن)
    Route::get('/admin/site-settings', [SiteSettingsController::class, 'edit'])
        ->name('admin.site-settings.edit');
    Route::post('/admin/site-settings', [SiteSettingsController::class, 'update'])
        ->name('admin.site-settings.update');

    // طباعة استمارة المنخرط
    Route::get('/members/{member}/print-form', [MemberPrintController::class, 'show'])
        ->name('members.print-form');
Route::get('/who-am-i', function () {
    dd(auth()->user()?->id, auth()->user()?->email, auth()->user()?->role);
})->middleware('auth');

    // /me يوجه حسب الدور
    Route::get('/me', function () {
        $user = auth()->user();
        return redirect()->route($user->profileRouteName());
    })->name('profile.redirect');
});

// لا حاجة لروت إضافي بـ PublicFacilityController ما دام عندك FacilityPublicController
