<?php

namespace App\Services;

use App\Models\User;
use App\Models\Notification;
use Illuminate\Support\Facades\Mail;

class NotificationService
{
    public function send(User \$user, string \$title, string \$message, string \$type = 'info', array \$channels = ['in_app'])
    {
        \$notification = Notification::create([
            'user_id' => \$user->id,
            'title' => \$title,
            'message' => \$message,
            'type' => \$type,
            'channel' => implode(',', \$channels),
        ]);

        foreach (\$channels as \$channel) {
            match(\$channel) {
                'email' => \$this->sendEmail(\$user, \$title, \$message),
                'sms' => \$this->sendSMS(\$user, \$message),
                'push' => \$this->sendPushNotification(\$user, \$title, \$message),
                'in_app' => null,
                default => null,
            };
        }

        return \$notification;
    }

    private function sendEmail(User \$user, string \$subject, string \$message)
    {
        try {
            Mail::send('emails.notification', [
                'subject' => \$subject,
                'message' => \$message,
            ], function (\$mail) use (\$user, \$subject) {
                \$mail->to(\$user->email)->subject(\$subject);
            });
        } catch (\Exception \$e) {
            \Log::error('Email notification failed: ' . \$e->getMessage());
        }
    }

    private function sendSMS(User \$user, string \$message)
    {
        // تطبيق إرسال SMS عبر Twilio أو مزود جزائري
        try {
            // \$twilio->messages->create(\$user->phone, [...]);
        } catch (\Exception \$e) {
            \Log::error('SMS notification failed: ' . \$e->getMessage());
        }
    }

    private function sendPushNotification(User \$user, string \$title, string \$message)
    {
        // تطبيق إرسال Push notifications عبر Firebase
        try {
            // firebase->messaging()->send([...]);
        } catch (\Exception \$e) {
            \Log::error('Push notification failed: ' . \$e->getMessage());
        }
    }

    public function broadcastNotification(array \$users, string \$title, string \$message, array \$channels = ['in_app', 'email'])
    {
        foreach (\$users as \$user) {
            \$this->send(\$user, \$title, \$message, 'info', \$channels);
        }
    }
}
