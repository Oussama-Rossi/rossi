<?php

namespace App\Services;

use App\Models\Payment;
use Illuminate\Support\Facades\Http;

class PaymentGatewayService
{
    public function processPayment(Payment \$payment, string \$gateway)
    {
        return match(\$gateway) {
            'chargily' => \$this->processChargilyPayment(\$payment),
            'cib' => \$this->processCIBPayment(\$payment),
            default => throw new \Exception('Gateway غير مدعوم'),
        };
    }

    private function processChargilyPayment(Payment \$payment)
    {
        \$response = Http::withHeaders([
            'Authorization' => 'Bearer ' . config('dcms.payment_gateways.chargily.api_key'),
        ])->post(config('dcms.payment_gateways.chargily.base_url') . '/invoices', [
            'amount' => (int)(\$payment->amount * 100),
            'currency' => 'DZD',
            'description' => 'Booking Payment',
            'client_email' => \$payment->user->email,
            'metadata' => [
                'payment_id' => \$payment->id,
                'user_id' => \$payment->user_id,
            ],
        ]);

        \$payment->update([
            'gateway_response' => \$response->json(),
        ]);

        return [
            'checkout_url' => \$response->json('checkout_url'),
            'payment_id' => \$payment->id,
        ];
    }

    private function processCIBPayment(Payment \$payment)
    {
        // تطبيق تكامل CIB/SATIM
        \$response = Http::post(config('dcms.payment_gateways.cib.base_url') . '/pay', [
            'merchant_id' => config('dcms.payment_gateways.cib.merchant_id'),
            'amount' => (int)(\$payment->amount * 100),
            'currency' => 'DZD',
            'reference' => \$payment->transaction_id,
            'customer_email' => \$payment->user->email,
        ]);

        \$payment->update([
            'gateway_response' => \$response->json(),
        ]);

        return \$response->json();
    }

    public function handleGatewayCallback(\Illuminate\Http\Request \$request)
    {
        \$gateway = \$request->input('gateway');

        return match(\$gateway) {
            'chargily' => \$this->handleChargilyCallback(\$request),
            'cib' => \$this->handleCIBCallback(\$request),
            default => null,
        };
    }

    private function handleChargilyCallback(\Illuminate\Http\Request \$request)
    {
        \$paymentId = \$request->input('metadata.payment_id');
        \$status = \$request->input('status');

        \$payment = Payment::find(\$paymentId);

        if (\$status === 'paid') {
            \$payment->markAsCompleted();
        } elseif (\$status === 'failed') {
            \$payment->update(['status' => 'failed']);
        }

        return \$payment;
    }

    private function handleCIBCallback(\Illuminate\Http\Request \$request)
    {
        // معالجة callback من CIB
        \$reference = \$request->input('reference');
        \$status = \$request->input('status');

        \$payment = Payment::where('transaction_id', \$reference)->first();

        if (\$payment && \$status === 'success') {
            \$payment->markAsCompleted();
        }

        return \$payment;
    }
}
