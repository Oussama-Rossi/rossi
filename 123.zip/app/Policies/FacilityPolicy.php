<?php

namespace App\Policies;

use App\Models\Facility;
use App\Models\User;

class FacilityPolicy
{
    public function viewAny(User $user): bool
    {
        return in_array($user->role, ['admin', 'unit_manager']);
    }

    public function view(User $user, Facility $facility): bool
    {
        if ($user->role === 'admin') {
            return true;
        }

        // رئيس الوحدة يرى وحدته فقط
        if ($user->role === 'unit_manager') {
            return $user->facility_id === $facility->id;
        }

        return false;
    }

    public function create(User $user): bool
    {
        // رئيس الوحدة لا ينشئ وحدات
        return $user->role === 'admin';
    }

    public function update(User $user, Facility $facility): bool
    {
        if ($user->role === 'admin') {
            return true;
        }

        if ($user->role === 'unit_manager') {
            return $user->facility_id === $facility->id;
        }

        return false;
    }

    public function delete(User $user, Facility $facility): bool
    {
        // منع حذف الوحدات للجميع ما عدا الأدمن إن أردت
        return $user->role === 'admin';
    }
}
