<?php

namespace App\Policies;

use App\Models\User;

class UserPolicy
{
    /**
     * من يمكنه رؤية قائمة الموظفين؟
     * فقط المدير العام (الذي ليس لديه facility_id محدد)
     */
    public function viewAny(User $user): bool
    {
        return $user->facility_id === null;
    }

    /**
     * من يمكنه إنشاء موظف جديد؟
     * فقط المدير العام
     */
    public function create(User $user): bool
    {
        return $user->facility_id === null;
    }

    /**
     * من يمكنه التعديل؟
     * المدير العام فقط
     */
    public function update(User $user, User $model): bool
    {
        return $user->facility_id === null;
    }

    /**
     * من يمكنه الحذف؟
     * المدير العام فقط، ولا يمكنه حذف نفسه
     */
    public function delete(User $user, User $model): bool
    {
        return $user->facility_id === null && $user->id !== $model->id;
    }
}
