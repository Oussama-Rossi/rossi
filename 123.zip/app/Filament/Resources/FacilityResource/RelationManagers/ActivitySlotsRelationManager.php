<?php

namespace App\Filament\Resources\FacilityResource\RelationManagers;

use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\RelationManagers\RelationManager;
use Filament\Tables;
use Filament\Tables\Table;

class ActivitySlotsRelationManager extends RelationManager
{
    // اسم العلاقة كما هو في موديل Facility: activitySlots()
    protected static string $relationship = 'activitySlots';

    protected static ?string $title = 'حصص الديوان';

    public function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\TextInput::make('sport_type')
                    ->label('النشاط')
                    ->placeholder('مثلاً: سباحة')
                    ->required()
                    ->maxLength(255),

                Forms\Components\TextInput::make('day_of_week')
                    ->label('اليوم')
                    ->placeholder('مثلاً: الأحد')
                    ->required()
                    ->maxLength(50),

                Forms\Components\TimePicker::make('start_time')
                    ->label('من')
                    ->required(),

                Forms\Components\TimePicker::make('end_time')
                    ->label('إلى')
                    ->required(),

                Forms\Components\TextInput::make('capacity')
                    ->label('السعة القصوى')
                    ->numeric()
                    ->minValue(1)
                    ->default(20)
                    ->required(),

                Forms\Components\TextInput::make('current_count')
                    ->label('محجوز حالياً')
                    ->numeric()
                    ->minValue(0)
                    ->default(0)
                    ->disabled()
                    ->dehydrated(false),

                Forms\Components\Toggle::make('is_active')
                    ->label('نشِط؟')
                    ->default(true),
            ]);
    }

    public function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('sport_type')
                    ->label('النشاط')
                    ->searchable(),

                Tables\Columns\TextColumn::make('day_of_week')
                    ->label('اليوم')
                    ->sortable(),

                Tables\Columns\TextColumn::make('start_time')
                    ->label('من')
                    ->time('H:i'),

                Tables\Columns\TextColumn::make('end_time')
                    ->label('إلى')
                    ->time('H:i'),

                Tables\Columns\TextColumn::make('current_count')
                    ->label('محجوز'),

                Tables\Columns\TextColumn::make('capacity')
                    ->label('السعة'),

                Tables\Columns\IconColumn::make('is_active')
                    ->label('نشِط')
                    ->boolean(),
            ])
            ->headerActions([
                Tables\Actions\CreateAction::make()
                    ->label('إضافة حصة جديدة'),
            ])
            ->actions([
                Tables\Actions\EditAction::make()->label('تعديل'),
                Tables\Actions\DeleteAction::make()->label('حذف'),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make()->label('حذف المحدد'),
                ]),
            ]);
    }
}
