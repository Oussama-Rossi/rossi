<?php

namespace App\Filament\Resources;

use App\Filament\Resources\MemberResource\Pages;
use App\Models\Member;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class MemberResource extends Resource
{
    protected static ?string $model = Member::class;
    protected static ?string $navigationIcon = 'heroicon-o-user-group';
    protected static ?string $navigationLabel = 'المنخرطين';
    protected static ?string $modelLabel = 'منخرط';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Tabs::make('ملف المنخرط')
                    ->tabs([
                        // التبويب 1: المعلومات الشخصية
                        Forms\Components\Tabs\Tab::make('المعلومات الشخصية')
                            ->schema([
                                Forms\Components\TextInput::make('registration_number')
                                    ->label('رقم التسجيل')
                                    ->disabled() // لا يمكن تعديله يدوياً
                                    ->dehydrated(false), // لا يرسل عند الحفظ إذا كان فارغاً

                                Forms\Components\TextInput::make('first_name')->label('الاسم')->required(),
                                Forms\Components\TextInput::make('last_name')->label('اللقب')->required(),
                                Forms\Components\DatePicker::make('birth_date')->label('تاريخ الميلاد')->required(),
                                Forms\Components\TextInput::make('birth_place')->label('مكان الميلاد')->required(),
                                Forms\Components\Select::make('gender')
                                    ->label('الجنس')
                                    ->options(['male' => 'ذكر', 'female' => 'أنثى'])
                                    ->required(),
                                Forms\Components\TextInput::make('phone')->label('الهاتف')->tel()->required(),
                               Forms\Components\TextInput::make('address')
    ->label('العنوان')
    ->required() // <--- أضف هذا السطر
    ->columnSpanFull(),

                            ])->columns(2),

                        // التبويب 2: الرياضة والوثائق
                        Forms\Components\Tabs\Tab::make('الرياضة والوثائق')
                            ->schema([
                                Forms\Components\Select::make('facility_id')
                                    ->label('المرفق')
                                    ->relationship('facility', 'name')
                                    // إذا كان المدير مخصصاً لمرفق، نثبت هذا المرفق ونمنع تغييره
                                    ->default(fn () => auth()->user()->facility_id)
                                    ->disabled(fn () => auth()->user()->isFacilityManager())
                                    ->required(),

                                Forms\Components\Select::make('sport_type')
                                    ->label('الرياضة')
                                    ->options([
                                        'swimming' => 'السباحة',
                                        'karate' => 'كاراتيه',
                                        'football' => 'كرة القدم',
                                        'fitness' => 'لياقة بدنية',
                                    ])
                                    ->required(),

                                Forms\Components\TextInput::make('time_slot')->label('التوقيت المختار'),

                                Forms\Components\Section::make('الوثائق المرفقة')
                                    ->schema([
                                        Forms\Components\FileUpload::make('doc_photo')->label('صورة شمسية')->image()->directory('members_docs')->openable(),
                                        Forms\Components\FileUpload::make('doc_identity')->label('الوثائق')->directory('members_docs')->openable(),
                                        Forms\Components\FileUpload::make('doc_medical')->label('الشهادة الطبية')->directory('members_docs')->openable(),
                                    ])->columns(3),
                            ]),

                        // التبويب 3: الحالة
                        Forms\Components\Tabs\Tab::make('الإدارة')
                            ->schema([
                                Forms\Components\Toggle::make('is_paid')->label('خالص (مدفوع)'),
                                Forms\Components\Select::make('status')
                                    ->label('حالة الملف')
                                    ->options([
                                        'pending' => 'قيد الدراسة',
                                        'approved' => 'مقبول',
                                        'rejected' => 'مرفوض',
                                    ])->default('pending'),
                            ]),
                    ])->columnSpanFull()
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('registration_number')->label('رقم الملف')->searchable(),
                Tables\Columns\TextColumn::make('first_name')->label('الاسم')->searchable(),
                Tables\Columns\TextColumn::make('last_name')->label('اللقب')->searchable(),
                Tables\Columns\TextColumn::make('facility.name')->label('المرفق')->badge(),
                Tables\Columns\TextColumn::make('sport_type')->label('الرياضة'),
                Tables\Columns\IconColumn::make('is_paid')->label('مدفوع')->boolean(),
                Tables\Columns\TextColumn::make('status')
                    ->label('الحالة')
                    ->badge()
                    ->color(fn (string $state): string => match ($state) {
                        'approved' => 'success',
                        'rejected' => 'danger',
                        'pending' => 'warning',
                    }),
            ])
            ->defaultSort('created_at', 'desc')
            ->filters([
                // فلاتر
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListMembers::route('/'),
            'create' => Pages\CreateMember::route('/create'),
            'edit' => Pages\EditMember::route('/{record}/edit'),
        ];
    }

    // دالة العزل (Scoping) - تأكد أنها داخل الكلاس (قبل القوس الأخير)
    public static function getEloquentQuery(): \Illuminate\Database\Eloquent\Builder
    {
        $query = parent::getEloquentQuery();

        // إذا كان المستخدم الحالي "مدير مرفق" (ليس فارغاً)
        if (auth()->check() && auth()->user()->facility_id !== null) {
            $query->where('facility_id', auth()->user()->facility_id);
        }

        return $query;
    }
}
