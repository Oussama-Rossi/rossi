<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ClubResource\Pages;
use App\Models\Club;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;

class ClubResource extends Resource
{
    protected static ?string $model = Club::class;

    protected static ?string $navigationIcon = 'heroicon-o-building-library';

    protected static ?string $navigationLabel = 'النوادي';
    protected static ?string $pluralModelLabel = 'النوادي الرياضية';
    protected static ?string $modelLabel = 'نادي رياضي';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                TextInput::make('name')
                    ->label('اسم النادي')
                    ->required()
                    ->maxLength(255),

                TextInput::make('president_name')
                    ->label('اسم رئيس النادي')
                    ->required()
                    ->maxLength(255),

                TextInput::make('registration_number')
                    ->label('رقم الاعتماد')
                    ->required()
                    ->maxLength(255),

                TextInput::make('phone')
                    ->label('رقم الهاتف')
                    ->tel()
                    ->maxLength(50),

                TextInput::make('sport_activity')
                    ->label('النشاط الرئيسي')
                    ->maxLength(255),

                Toggle::make('is_active')
                    ->label('نادي مفعل')
                    ->default(false),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('name')
                    ->label('النادي')
                    ->searchable()
                    ->sortable(),

                TextColumn::make('president_name')
                    ->label('الرئيس')
                    ->searchable(),

                TextColumn::make('sport_activity')
                    ->label('النشاط')
                    ->sortable(),

                TextColumn::make('registration_number')
                    ->label('رقم الاعتماد'),

                IconColumn::make('is_active')
                    ->label('مفعل')
                    ->boolean(),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\DeleteBulkAction::make(),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListClubs::route('/'),
            'create' => Pages\CreateClub::route('/create'),
            'edit'   => Pages\EditClub::route('/{record}/edit'),
        ];
    }

    // السماح بعرض Resource: هنا الأدمن فقط
    public static function canViewAny(): bool
    {
        return auth()->user()?->isAdmin();
    }
}
