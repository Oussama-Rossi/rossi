<?php

namespace App\Filament\Resources;

use App\Filament\Resources\FacilityResource\Pages;
use App\Filament\Resources\FacilityResource\RelationManagers;
use App\Models\Facility;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Auth;


class FacilityResource extends Resource
{
    protected static ?string $model = Facility::class;

    protected static ?string $navigationIcon = 'heroicon-o-rectangle-stack';



// داخل الكلاس FacilityResource
public static function getEloquentQuery(): Builder
{
    $query = parent::getEloquentQuery();

    $user = Auth::user();

    if ($user && $user->role === 'unit_manager') {
        // يرى فقط وحدته
        $query->where('id', $user->facility_id);
    }

    return $query;
}

// منع الحذف لرئيس الوحدة
public static function canDelete($record): bool
{
    $user = Auth::user();

    if ($user && $user->role === 'unit_manager') {
        return false;
    }

    return parent::canDelete($record);
}

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Tabs::make('FacilityTabs')
                    ->tabs([
                        Forms\Components\Tabs\Tab::make('معلومات المرفق')
                            ->schema([
                                Forms\Components\Section::make()
                                    ->schema([
                                        Forms\Components\TextInput::make('name')
                                            ->label('اسم المرفق')
                                            ->required(),

                                        Forms\Components\Select::make('status')
                                            ->label('الحالة')
                                            ->options([
                                                'available'   => 'مفتوح',
                                                'maintenance' => 'صيانة',
                                                'closed'      => 'مغلق',
                                            ])
                                            ->required(),

                                        Forms\Components\TextInput::make('price_per_hour')
                                            ->label('سعر الساعة (للحجز الحر)')
                                            ->numeric()
                                            ->nullable(),
                                    ])
                                    ->columns(2),

                                Forms\Components\Section::make('إعدادات التسجيل (للمواطنين)')
                                    ->description('هذه المعلومات ستظهر في استمارة التسجيل')
                                    ->schema([
                                        Forms\Components\TagsInput::make('available_sports')
                                            ->label('الرياضات المتوفرة')
                                            ->placeholder('أكتب الرياضة واضغط Enter (مثلاً: سباحة، كاراتيه)')
                                            ->reorderable(),

                                        Forms\Components\TagsInput::make('work_hours')
                                            ->label('التوقيتات المتاحة (أفواج)')
                                            ->placeholder('أضف توقيتاً (مثلاً: 08:00-10:00)')
                                            ->reorderable(),
                                    ]),
                            ]),

                        Forms\Components\Tabs\Tab::make('معرض الصور')
                            ->schema([
                                Forms\Components\Repeater::make('images')
                                    ->label('صور المرفق')
                                    ->relationship('images')
                                    ->schema([
                                        Forms\Components\FileUpload::make('path')
                                            ->label('الصورة')
                                            ->image()
                                            ->directory('facility-images')
                                            ->required(),

                                        Forms\Components\TextInput::make('caption')
                                            ->label('وصف (اختياري)')
                                            ->maxLength(255)
                                            ->nullable(),

                                        Forms\Components\TextInput::make('order')
                                            ->label('ترتيب العرض')
                                            ->numeric()
                                            ->default(0),
                                    ])
                                    ->orderable('order')
                                    ->minItems(0)
                                    ->collapsed(),
                            ]),
                    ]),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('name')
                    ->label('اسم المرفق')
                    ->searchable()
                    ->sortable(),

                Tables\Columns\TextColumn::make('status')
                    ->label('الحالة')
                    ->badge()
                    ->formatStateUsing(fn (string $state) => match ($state) {
                        'available'   => 'مفتوح',
                        'maintenance' => 'صيانة',
                        'closed'      => 'مغلق',
                        default       => $state,
                    }),

                Tables\Columns\TextColumn::make('price_per_hour')
                    ->label('سعر الساعة')
                    ->money('DZD', true)
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),

                Tables\Columns\TextColumn::make('created_at')
                    ->label('تاريخ الإنشاء')
                    ->date('Y-m-d')
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                //
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            RelationManagers\ActivitySlotsRelationManager::class,
        ];
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListFacilities::route('/'),
            'create' => Pages\CreateFacility::route('/create'),
            'edit'   => Pages\EditFacility::route('/{record}/edit'),
        ];
    }
}
