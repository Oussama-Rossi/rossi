<?php

namespace App\Filament\Resources;

use App\Filament\Resources\EmployeeResource\Pages;
use App\Models\Employee;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;

class EmployeeResource extends Resource
{
    protected static ?string $model = Employee::class;
    protected static ?string $navigationIcon = 'heroicon-o-users';
    protected static ?string $navigationLabel = 'الموظفين';
    protected static ?string $modelLabel = 'موظف';
    protected static ?string $pluralModelLabel = 'الموظفين';

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                Forms\Components\Section::make('البيانات الشخصية')
                    ->schema([
                        Forms\Components\TextInput::make('first_name')->label('الاسم')->required(),
                        Forms\Components\TextInput::make('last_name')->label('اللقب')->required(),
                        Forms\Components\DatePicker::make('birth_date')->label('تاريخ الميلاد')->required(),
                        Forms\Components\TextInput::make('birth_place')->label('مكان الميلاد')->required(),
                        Forms\Components\Select::make('gender')
                            ->label('الجنس')
                            ->options([
                                'male' => 'ذكر',
                                'female' => 'أنثى',
                            ])->required(),
                        Forms\Components\TextInput::make('phone')->label('الهاتف'),
                        
                        // حقل العنوان (تم إصلاحه)
                        Forms\Components\TextInput::make('address')
                            ->label('العنوان')
                            ->required() 
                            ->columnSpanFull(),
                    ])->columns(2),

                Forms\Components\Section::make('بيانات الوظيفة')
                    ->schema([
                        Forms\Components\TextInput::make('job_title')->label('المسمى الوظيفي')->required(),
                        Forms\Components\DatePicker::make('join_date')->label('تاريخ التوظيف')->required(),
                        Forms\Components\Select::make('contract_type')
                            ->label('نوع العقد')
                            ->options([
                                'CDI' => 'عقد دائم (CDI)',
                                'CDD' => 'عقد محدد المدة (CDD)',
                                'CTA' => 'CTA',
                                'DAIP' => 'DAIP',
                            ])->required(),
                        Forms\Components\TextInput::make('base_salary')->label('الراتب')->numeric(),
                        Forms\Components\Select::make('status')
                            ->label('الحالة')
                            ->options([
                                'active' => 'نشط',
                                'on_leave' => 'عطلة',
                                'terminated' => 'منتهية مهامه',
                            ])->default('active')->required(),
                    ])->columns(2),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('first_name')->label('الاسم')->searchable()->sortable(),
                Tables\Columns\TextColumn::make('last_name')->label('اللقب')->searchable()->sortable(),
                Tables\Columns\TextColumn::make('job_title')->label('الوظيفة')->searchable(),
                Tables\Columns\TextColumn::make('contract_type')->label('العقد')->badge(),
                Tables\Columns\TextColumn::make('join_date')->label('تاريخ التوظيف')->date(),
                Tables\Columns\TextColumn::make('status')
                    ->label('الحالة')
                    ->badge()
                    ->color(fn (string $state): string => match ($state) {
                        'active' => 'success',
                        'on_leave' => 'warning',
                        'terminated' => 'danger',
                        default => 'gray',
                    }),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('status')
                    ->label('تصفية حسب الحالة')
                    ->options([
                        'active' => 'نشط',
                        'on_leave' => 'عطلة',
                    ]),
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                // زر الشهادة
                Tables\Actions\Action::make('certificate')
                    ->label('شهادة عمل')
                    ->icon('heroicon-o-document-text')
                    ->url(fn (Employee $record) => route('employees.certificate', $record))
                    ->openUrlInNewTab(),
            ]);
    }
    
    public static function getPages(): array
    {
        return [
            'index' => Pages\ListEmployees::route('/'),
            'create' => Pages\CreateEmployee::route('/create'),
            'edit' => Pages\EditEmployee::route('/{record}/edit'),
        ];
    }
}
