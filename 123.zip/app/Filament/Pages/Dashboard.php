<?php

namespace App\Filament\Pages;

use Filament\Pages\Dashboard as BaseDashboard;
use Filament\Pages\Actions\Action;

class Dashboard extends BaseDashboard
{
    protected static ?string $navigationIcon = 'heroicon-o-home';

    protected function getActions(): array
    {
        return [
            Action::make('home')
                ->label('العودة إلى الموقع العام')
                ->color('gray')
                ->icon('heroicon-o-arrow-uturn-left')
                ->url(route('home'))   // مسار الصفحة الرئيسية عندك
                ->openUrlInNewTab(false),
        ];
    }
}
