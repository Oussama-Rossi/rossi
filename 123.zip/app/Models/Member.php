<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Member extends Model
{
    protected $fillable = [
        'user_id',
        'registration_number',
        'first_name',
        'last_name',
        'birth_date',
        'birth_place',
        'gender',
        'phone',
        'address',
        'facility_id',
        'sport_type',
        'time_slot',
        'status',
        'club_time_slot_id',
        // أضف أي أعمدة أخرى لديك هنا
    ];

    public function facility()
    {
        return $this->belongsTo(Facility::class);
    }

    public function timeSlot()
    {
        return $this->belongsTo(ClubTimeSlot::class, 'club_time_slot_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
protected $casts = [
    'birth_date' => 'date',
];

}
