<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Club extends Model
{
    protected $fillable = [
        'user_id',
        'facility_id',
        'name',
        'president_name',
        'phone',
        'sport_activity',
        'registration_number',
        'logo',
        'is_active',
    ];

    public function facility()
    {
        return $this->belongsTo(Facility::class);
    }
public function timeSlots()
{
    return $this->hasMany(ClubTimeSlot::class);
}

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
