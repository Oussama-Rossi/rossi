<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Model;

class SportsUnit extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'name',
        'description',
        'type',
        'capacity',
        'price_per_hour',
        'location',
        'amenities',
        'image',
        'is_available',
        'opening_time',
        'closing_time',
        'manager_id',
    ];

    protected function casts(): array
    {
        return [
            'is_available' => 'boolean',
            'opening_time' => 'datetime:H:i',
            'closing_time' => 'datetime:H:i',
        ];
    }

    public function manager(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function bookings(): HasMany
    {
        return $this->hasMany(Booking::class);
    }

    public function scopeAvailable($query)
    {
        return $query->where('is_available', true);
    }

    public function getTypeInArabicAttribute()
    {
        return [
            'swimming_pool' => 'حمام السباحة',
            'football_field' => 'ملعب كرة القدم',
            'sports_hall' => 'قاعة رياضية',
            'tennis_court' => 'ملعب التنس',
            'other' => 'أخرى',
        ][\$this->type] ?? 'نوع آخر';
    }
}
