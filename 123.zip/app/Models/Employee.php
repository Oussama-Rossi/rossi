<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Employee extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'user_id', 'first_name', 'last_name', 'birth_date', 'birth_place',
        'gender', 'phone', 'address', 'job_title', 'department',
        'join_date', 'contract_type', 'base_salary', 'nin', 'ssn', 'status'
    ];

    protected $casts = [
        'birth_date' => 'date',
        'join_date' => 'date',
    ];

    // الاسم الكامل
    public function getFullNameAttribute()
    {
        return "{$this->first_name} {$this->last_name}";
    }

    // ربط مع جدول المستخدمين
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
