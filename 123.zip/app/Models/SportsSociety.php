<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Model;

class SportsSociety extends Model
{
    use HasFactory, SoftDeletes;

    protected $table = 'sports_societies';

    protected $fillable = [
        'name',
        'description',
        'president_name',
        'president_email',
        'president_phone',
        'president_national_id',
        'headquarters_location',
        'members_count',
        'status',
        'rejection_reason',
        'approved_by',
        'approved_at',
        'license_document',
        'president_id_document',
    ];

    protected function casts(): array
    {
        return [
            'approved_at' => 'datetime',
        ];
    }

    public function agreements(): HasMany
    {
        return $this->hasMany(SocietyAgreement::class);
    }

    public function approver(): BelongsTo
    {
        return $this->belongsTo(User::class, 'approved_by');
    }

    public function scopePending($query)
    {
        return $query->where('status', 'pending');
    }

    public function approve()
    {
        \$this->update([
            'status' => 'approved',
            'approved_by' => auth()->id(),
            'approved_at' => now(),
        ]);
    }

    public function reject(\$reason)
    {
        \$this->update([
            'status' => 'rejected',
            'rejection_reason' => \$reason,
            'approved_by' => auth()->id(),
            'approved_at' => now(),
        ]);
    }
}
