<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use Filament\Models\Contracts\FilamentUser;
use Filament\Panel;

class User extends Authenticatable implements FilamentUser
{
    use HasApiTokens, HasFactory, Notifiable;

    // تعريف الأدوار المتاحة
 public const ROLES = [
    'admin'         => 'مدير عام',
    'unit_manager'  => 'رئيس وحدة',
    'club_manager'  => 'رئيس جمعية / نادي',
    'member'        => 'مستخدم عادي',
];

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'facility_id',
        'role',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
    ];

    // ربط المستخدم بالمرفق (الوحدة)
    public function facility()
    {
        return $this->belongsTo(Facility::class);
    }

    public function isFacilityManager(): bool
    {
        return $this->role === 'unit_manager';
    }
public function timeSlot()
{
    return $this->belongsTo(\App\Models\ClubTimeSlot::class, 'club_time_slot_id');
}


    public function isAdmin(): bool
    {
        return $this->role === 'admin';
    }

public function isClubManager(): bool
{
    return $this->role === 'club_manager';
}
    // السماح بدخول لوحة التحكم Filament
public function canAccessPanel(Panel $panel): bool
{
    // نتحقق أننا في لوحة "admin"
    if ($panel->getId() === 'admin') {
        // فقط المدير العام أو رئيس الوحدة يدخلون
        return $this->isAdmin() || $this->isFacilityManager();
    }

    // لو عندك Panels أخرى مستقبلاً
    return false;
}
public function profileRouteName(): string
{
    $adminRoles = ['admin', 'unit_manager'];

    return match (true) {
        in_array($this->role, $adminRoles) => 'filament.admin.pages.dashboard',
        $this->role === 'club'            => 'club.profile',
        $this->role === 'member'          => 'public.profile',
        default                           => 'home', // في حال لم يتم تعريف دور المستخدم
    };
}



    };
