<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FacilityActivitySlot extends Model
{
    protected $fillable = [
        'facility_id', 'sport_type', 'day_of_week',
        'start_time', 'end_time', 'capacity', 'current_count', 'is_active'
    ];

    public function facility()
    {
        return $this->belongsTo(Facility::class);
    }
}
