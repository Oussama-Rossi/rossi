<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class FootballMatch extends Model {
    protected $guarded = [];
    protected $casts = ['match_date' => 'datetime', 'is_selling' => 'boolean'];
    public function tickets() { return $this->hasMany(Ticket::class); }
}
