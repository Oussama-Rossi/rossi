<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ClubTimeSlot extends Model
{
    protected $fillable = [
        'club_id',
        'facility_id',
        'sport_activity',
        'day_of_week',
        'start_time',
        'end_time',
        'capacity',
        'current_count',
        'is_active',
    ];

    public function club(): BelongsTo
    {
        return $this->belongsTo(Club::class);
    }

    public function facility(): BelongsTo
    {
        return $this->belongsTo(Facility::class);
    }

    public function clubMembers(): HasMany
    {
        return $this->hasMany(ClubMember::class);
    }

    public function getIsFullAttribute(): bool
    {
        return $this->current_count >= $this->capacity;
    }
}

