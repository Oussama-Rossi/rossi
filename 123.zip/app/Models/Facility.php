<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Facility extends Model
{
    use HasFactory;

protected $casts = [
    'available_sports' => 'array',
    'work_hours' => 'array',
];


protected $fillable = [
    'name',
    'address',
    'description',
    'phone',
    'email',
    'status',
    'price_per_hour',
    'available_sports',
    'work_hours',
];

        // أي أعمدة أخرى عندك...
    

    // علاقات
    public function clubs()
    {
        return $this->hasMany(Club::class);
    }
public function activitySlots()
{
    return $this->hasMany(FacilityActivitySlot::class);
}

    public function members()
    {
        return $this->hasMany(Member::class);
    }

    public function clubTimeSlots()
    {
        return $this->hasMany(\App\Models\ClubTimeSlot::class);
    }

    public function images()
    {
        return $this->hasMany(\App\Models\FacilityImage::class)->orderBy('order');
    }
}
