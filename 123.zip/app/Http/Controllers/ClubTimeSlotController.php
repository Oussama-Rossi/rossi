<?php

namespace App\Http\Controllers;

use App\Models\Club;
use App\Models\ClubTimeSlot;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ClubTimeSlotController extends Controller
{
    public function index()
    {
        $club = Club::where('user_id', Auth::id())
            ->with(['facility', 'timeSlots' => function ($q) {
                $q->orderBy('day_of_week')->orderBy('start_time');
            }])
            ->firstOrFail();

        // الحصص لهذا النادي
        $timeSlots = $club->timeSlots()->with('facility')->get();

        // لعرض الوحدات المتاحة للنادي (حسب تصميمك الحالي)
        $facilities = \App\Models\Facility::all();

        return view('club.dashboard', compact('club', 'timeSlots', 'facilities'));
    }

    public function store(Request $request)
    {
        $club = Club::where('user_id', Auth::id())->firstOrFail();

        $data = $request->validate([
            'facility_id'    => ['required', 'exists:facilities,id'],
            'sport_activity' => ['required', 'string', 'max:255'],
            'day_of_week'    => ['required', 'string', 'max:50'],
            'start_time'     => ['required', 'date_format:H:i'],
            'end_time'       => ['required', 'date_format:H:i', 'after:start_time'],
            'capacity'       => ['required', 'integer', 'min:1', 'max:200'],
        ]);

        $data['club_id']   = $club->id;
        $data['is_active'] = true;

        ClubTimeSlot::create($data);

        return back()->with('success', 'تم إضافة الحصة بنجاح.');
    }

    public function destroy(ClubTimeSlot $slot)
    {
        $club = Club::where('user_id', Auth::id())->firstOrFail();

        abort_if($slot->club_id !== $club->id, 403);

        if ($slot->current_count > 0) {
            return back()->with('error', 'لا يمكن حذف حصة تحتوي على منخرطين.');
        }

        $slot->delete();

        return back()->with('success', 'تم حذف الحصة بنجاح.');
    }
}
