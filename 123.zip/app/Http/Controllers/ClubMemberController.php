<?php

namespace App\Http\Controllers;

use App\Models\Club;
use App\Models\Member;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ClubMemberController extends Controller
{
    public function approve(Member $member)
    {
        // النادي الخاص بالمستخدم الحالي (رئيس النادي)
        $club = Club::where('user_id', Auth::id())->firstOrFail();

        // تأمين: المنخرط يجب أن يكون من هذا النادي
        if ($member->club_id !== $club->id) {
            abort(403);
        }

        $slot = $member->timeSlot; // ClubTimeSlot

        if (! $slot) {
            return back()->with('error', 'لا توجد حصة مرتبطة بهذا المنخرط.');
        }

        // إذا كانت الحصة ممتلئة
        if ($slot->current_count >= $slot->capacity) {
            return back()->with('error', 'هذه الحصة ممتلئة، يرجى اختيار حصة أخرى للمنخرط.');
        }

        // قبول المنخرط + زيادة العداد
        $member->status = 'approved';
        $member->save();

        $slot->increment('current_count');

        return back()->with('success', 'تم قبول المنخرط في الحصة بنجاح.');
    }

    public function reject(Member $member)
    {
        $club = Club::where('user_id', Auth::id())->firstOrFail();

        if ($member->club_id !== $club->id) {
            abort(403);
        }

        // في حالة كان مقبولاً مسبقاً، ننقص العدد
        if ($member->status === 'approved' && $member->timeSlot) {
            $member->timeSlot->decrement('current_count');
        }

        $member->status = 'rejected';
        $member->save();

        return back()->with('success', 'تم رفض طلب الانخراط.');
    }
}
