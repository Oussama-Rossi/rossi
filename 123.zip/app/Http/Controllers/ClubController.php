<?php

namespace App\Http\Controllers;

use App\Models\Club;
use App\Models\Facility;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class ClubController extends Controller
{
    // عرض صفحة تسجيل نادي / جمعية
    public function create()
    {
        // جلب الوحدات لعرضها في اختيار الوحدة
        $facilities = Facility::all();

        return view('front.register_club', compact('facilities'));
    }

    // حفظ النادي
    public function store(Request $request)
    {
        $request->validate([
            'club_name'          => 'required|string|max:255',
            'email'              => 'required|email|unique:users,email',
            'password'           => 'required|min:8',
            'president_name'     => 'required|string|max:255',
            'phone'              => 'required|string|max:50',
            'facility_id'        => 'required|exists:facilities,id',
            'sport_activity'     => 'nullable|string|max:255',
            'registration_number'=> 'nullable|string|max:255',
            'logo'               => 'nullable|image|max:2048',
        ]);

        // 1. إنشاء حساب المستخدم (رئيس النادي) كرئيس وحدة
        $user = User::create([
            'name'        => $request->president_name,
            'email'       => $request->email,
            'password'    => Hash::make($request->password),
            'facility_id' => $request->facility_id,
            'role'        => 'club_manager',
        ]);

        // 2. إنشاء ملف النادي وربطه بالرئيس وبالوحدة
        $club = new Club();
        $club->user_id             = $user->id;
        $club->facility_id         = $request->facility_id;
        $club->name                = $request->club_name;
        $club->president_name      = $request->president_name;
        $club->phone               = $request->phone;
        $club->sport_activity      = $request->sport_activity;
        $club->registration_number = $request->registration_number;
        $club->is_active           = false; // انتظار موافقة الإدارة

        if ($request->hasFile('logo')) {
            $club->logo = $request->file('logo')->store('clubs', 'public');
        }

        $club->save();

        // 3. تسجيل الدخول وتوجيهه للوحة النادي
        Auth::login($user);

        return redirect()->route('club.dashboard');
    }

public function profile()
{
    $club = Club::where('user_id', Auth::id())->firstOrFail();

    return view('front.club_profile', compact('club'));
}


    // لوحة تحكم رئيس النادي
    public function dashboard()
    {
        $club = Club::where('user_id', Auth::id())->firstOrFail();

        // يمكن لاحقاً منع الدخول إذا لم يتم التفعيل:
        // if (! $club->is_active) abort(403);

        return view('front.club_dashboard', compact('club'));
    }
}
