<?php

namespace App\Http\Controllers;

use App\Models\Facility;
use App\Models\Member;
use App\Models\Club;
use App\Models\FootballMatch;
use App\Models\User;
use App\Models\ClubTimeSlot;
use App\Models\FacilityActivitySlot;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    // الصفحة الرئيسية
    public function index()
    {
        $facilities = Facility::where('status', '!=', 'closed')->take(6)->get();
        $matches    = FootballMatch::where('match_date', '>=', now())->take(3)->get();

        // الإحصائيات العامة
        $totalMembers  = Member::count();
        $maleMembers   = Member::where('gender', 'male')->count();
        $femaleMembers = Member::where('gender', 'female')->count();

        $ageGroups = Member::selectRaw("
            SUM(CASE WHEN TIMESTAMPDIFF(YEAR, birth_date, CURDATE()) < 18 THEN 1 ELSE 0 END) as under_18,
            SUM(CASE WHEN TIMESTAMPDIFF(YEAR, birth_date, CURDATE()) BETWEEN 18 AND 29 THEN 1 ELSE 0 END) as age_18_29,
            SUM(CASE WHEN TIMESTAMPDIFF(YEAR, birth_date, CURDATE()) BETWEEN 30 AND 45 THEN 1 ELSE 0 END) as age_30_45,
            SUM(CASE WHEN TIMESTAMPDIFF(YEAR, birth_date, CURDATE()) > 45 THEN 1 ELSE 0 END) as over_45
        ")->first();

        $topSport = Member::select('sport_type', DB::raw('COUNT(*) as total'))
            ->groupBy('sport_type')
            ->orderByDesc('total')
            ->first();

        $topFacility = Member::select('facility_id', DB::raw('COUNT(*) as total'))
            ->groupBy('facility_id')
            ->orderByDesc('total')
            ->with('facility')
            ->first();

        $activeClubs = Club::where('is_active', true)->count();

        return view('welcome', compact(
            'facilities',
            'matches',
            'totalMembers',
            'maleMembers',
            'femaleMembers',
            'ageGroups',
            'topSport',
            'topFacility',
            'activeClubs'
        ));
    }

    // صفحة التسجيل (استمارة الانخراط)
    public function join()
    {
        $facilities = Facility::where('status', 'available')->get();

        // حصص الجمعيات
        $timeSlots = ClubTimeSlot::where('is_active', true)
            ->whereColumn('current_count', '<', 'capacity')
            ->with(['club', 'facility'])
            ->orderBy('day_of_week')
            ->orderBy('start_time')
            ->get();

        // حصص الديوان لكل مرفق/نشاط
        $facilitySlots = FacilityActivitySlot::where('is_active', true)
            ->whereColumn('current_count', '<', 'capacity')
            ->with('facility')
            ->orderBy('facility_id')
            ->orderBy('sport_type')
            ->orderBy('day_of_week')
            ->orderBy('start_time')
            ->get();

        return view('front.join', compact('facilities', 'timeSlots', 'facilitySlots'));
    }

    // حفظ طلب التسجيل وإنشاء الحساب
    public function storeJoin(Request $request)
    {
        $rules = [
            'subscription_type' => 'required|in:diwan,club',

            'email'       => 'required|email|unique:users,email',
            'password'    => 'required|min:8',
            'first_name'  => 'required|string',
            'last_name'   => 'required|string',
            'birth_date'  => 'required|date',
            'birth_place' => 'required|string',
            'address'     => 'required',
            'phone'       => 'required',
            'gender'      => 'required|in:male,female',

            // حقول الديوان
            'facility_id'              => 'required_if:subscription_type,diwan|exclude_if:subscription_type,club|exists:facilities,id',
            'sport_type'               => 'required_if:subscription_type,diwan|exclude_if:subscription_type,club',
            'facility_activity_slot_id'=> 'required_if:subscription_type,diwan|exclude_if:subscription_type,club|exists:facility_activity_slots,id',

            // حقل الحصة في الجمعية
            'club_time_slot_id'        => 'required_if:subscription_type,club|exclude_if:subscription_type,diwan|exists:club_time_slots,id',
        ];

        $validated = $request->validate($rules);

        $clubSlot   = null;
        $diwanSlot  = null;

        // تحقق من حصة الجمعية
        if ($validated['subscription_type'] === 'club') {
            $clubSlot = ClubTimeSlot::findOrFail($validated['club_time_slot_id']);

            if (! $clubSlot->is_active || $clubSlot->current_count >= $clubSlot->capacity) {
                return back()->withInput()->withErrors([
                    'club_time_slot_id' => 'هذه الحصة ممتلئة أو غير متاحة، يرجى اختيار حصة أخرى.',
                ]);
            }
        }

        // تحقق من حصة الديوان
        if ($validated['subscription_type'] === 'diwan') {
            $diwanSlot = FacilityActivitySlot::findOrFail($validated['facility_activity_slot_id']);

            if (! $diwanSlot->is_active || $diwanSlot->current_count >= $diwanSlot->capacity) {
                return back()->withInput()->withErrors([
                    'facility_activity_slot_id' => 'هذه الحصة ممتلئة أو غير متاحة، يرجى اختيار حصة أخرى.',
                ]);
            }
        }

        // إنشاء المستخدم
        $user = User::create([
            'name'     => $validated['first_name'].' '.$validated['last_name'],
            'email'    => $validated['email'],
            'password' => Hash::make($validated['password']),
        ]);

        // رقم الملف
        $count      = Member::whereYear('created_at', date('Y'))->count() + 1;
        $reg_number = date('Y').'/'.str_pad($count, 4, '0', STR_PAD_LEFT);

        // إنشاء المنخرط
        $member = new Member();
        $member->user_id             = $user->id;
        $member->registration_number = $reg_number;

        // نملأ البيانات العامة المشتركة
        $member->fill(collect($validated)->except([
            'email',
            'password',
            'club_time_slot_id',
            'facility_activity_slot_id',
        ])->toArray());

        $member->status = 'pending';

        if ($validated['subscription_type'] === 'club' && $clubSlot) {
            // ربط المنخرط بحصة الجمعية
            $member->club_time_slot_id        = $clubSlot->id;
            $member->facility_activity_slot_id = null;

            // أخذ الرياضة والوحدة من الحصة تلقائياً
            $member->sport_type  = $clubSlot->sport_activity;
            $member->facility_id = $clubSlot->facility_id;
        } elseif ($validated['subscription_type'] === 'diwan' && $diwanSlot) {
            // ربط المنخرط بحصة الديوان
            $member->facility_activity_slot_id = $diwanSlot->id;
            $member->club_time_slot_id         = null;

            // أخذ الرياضة والوحدة من الحصة
            $member->sport_type  = $diwanSlot->sport_type;
            $member->facility_id = $diwanSlot->facility_id;
        }

        $member->save();

        // تحديث العدادات
        if ($clubSlot) {
            $clubSlot->increment('current_count');
        }

        if ($diwanSlot) {
            $diwanSlot->increment('current_count');
        }

        Auth::login($user);

        return redirect()->route('public.download.form', $member->id);
    }

    // تحميل الاستمارة PDF
    public function downloadForm($id)
    {
        $member = Member::with('facility')->findOrFail($id);

        $mpdf = new \Mpdf\Mpdf([
            'mode'         => 'utf-8',
            'format'       => 'A4',
            'margin_left'  => 10,
            'margin_right' => 10,
            'margin_top'   => 10,
            'margin_bottom'=> 10,
            'default_font' => 'tajawal',
        ]);

        $mpdf->autoScriptToLang = true;
        $mpdf->autoLangToFont   = true;

        $html = view('front.documents.membership_form', compact('member'))->render();

        $mpdf->WriteHTML($html);

        $filename = 'membership_' . str_replace('/', '_', $member->registration_number) . '.pdf';

        return $mpdf->Output($filename, 'I');
    }

    // عرض النوادي
    public function clubs()
    {
        $clubs = Club::where('is_active', true)->get();

        return view('front.clubs', compact('clubs'));
    }

    // صفحة تسجيل نادي جديد
    public function registerClub()
    {
        return view('front.register_club');
    }

    public function storeClub(Request $request)
    {
        // منطق حفظ النادي (لاحقاً)
    }
}
