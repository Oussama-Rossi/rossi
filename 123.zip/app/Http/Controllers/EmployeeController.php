<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Barryvdh\DomPDF\Facade\Pdf;
use ArPHP\I18N\Arabic; 

class EmployeeController extends Controller
{
    public function index()
    {
        $employees = Employee::latest()->paginate(10);
        return view('employees.index', compact('employees'));
    }

    public function create()
    {
        return view('employees.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'birth_date' => 'required|date',
            'birth_place' => 'required|string',
            'gender' => 'required|in:male,female',
            'address' => 'required|string',
            'phone' => 'nullable|string',
            'job_title' => 'required|string',
            'department' => 'nullable|string',
            'join_date' => 'required|date',
            'contract_type' => 'required|string',
            'base_salary' => 'nullable|numeric',
            'ssn' => 'nullable|string',
        ]);

        Employee::create($validated);
        return redirect()->route('employees.index')->with('success', 'تم إضافة الموظف بنجاح');
    }

    public function edit(Employee $employee)
    {
        return view('employees.edit', compact('employee'));
    }

    public function update(Request $request, Employee $employee)
    {
        $validated = $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'birth_date' => 'required|date',
            'birth_place' => 'required|string',
            'gender' => 'required|in:male,female',
            'address' => 'required|string',
            'job_title' => 'required|string',
            'join_date' => 'required|date',
            'contract_type' => 'required|string',
            'status' => 'required|in:active,on_leave,terminated,retired',
        ]);

        $employee->update($validated);
        return redirect()->route('employees.index')->with('success', 'تم التحديث');
    }

    public function destroy(Employee $employee)
    {
        $employee->delete();
        return redirect()->route('employees.index')->with('success', 'تم الحذف');
    }

    public function downloadCertificate(Employee $employee)
    {
        $arabic = new Arabic();
        
        // دالة المعالجة
        $fix = function($text) use ($arabic) {
            return $arabic->utf8Glyphs($text);
        };

        $data = [
            // العناوين
            'header_1' => $fix('الجمهورية الجزائرية الديمقراطية الشعبية'),
            'header_2' => $fix('وزارة الشباب والرياضة'),
            'header_3' => $fix('ديوان المركب المتعدد الرياضات - قالمة'),
            'doc_title' => $fix('شهـــــادة عمــــــل'),
            
            // النصوص (Labels)
            'text_intro' => $fix('يشهد مدير ديوان المركب المتعدد الرياضات،'),
            'text_name' => $fix('أن السيد(ة):'),
            'text_born' => $fix('المولود(ة) بتاريخ:'),
            'text_at' => $fix('بـ:'),
            'text_job' => $fix('يشغل منصب:'),
            'text_contract_1' => $fix('وذلك بموجب عقد عمل'), // أزلت النقطتين لأنها في الجدول
            'text_contract_2' => $fix('ابتداءً من تاريخ:'),
            'text_contract_3' => $fix('إلى غاية يومنا هذا.'),
            'text_footer' => $fix('سلمت هذه الشهادة للمعني لاستعمالها في إطار ما يسمح به القانون.'),
            'location_date' => $fix('حرر بـ قالمة في:'),
            'manager_title' => $fix('المدير'),
            'signature_placeholder' => $fix('(الختم والتوقيع)'),

            // بيانات الموظف
            // ملاحظة: أزلنا $fix عن الاسم ليظهر كما هو (لاتيني أو عربي) بدون عكس الحروف
            'emp_name' => $employee->first_name . ' ' . $employee->last_name,
            'emp_birth_place' => $fix($employee->birth_place),
            'emp_job' => $fix($employee->job_title),
            
            // التواريخ
            'emp_birth_date' => $employee->birth_date->format('Y/m/d'),
            'emp_join_date' => $employee->join_date->format('Y/m/d'),
            'emp_contract' => $employee->contract_type,
            'current_date' => date('Y/m/d'),
        ];

        $pdf = Pdf::loadView('employees.documents.work_certificate', $data);
        $pdf->setOption(['isRemoteEnabled' => true, 'defaultFont' => 'DejaVu Sans']);

        return $pdf->stream('certificate.pdf');

    }
}
