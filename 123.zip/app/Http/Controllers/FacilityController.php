<?php

namespace App\Http\Controllers;

use App\Models\Facility;
use Illuminate\Http\Request;

class FacilityController extends Controller
{
    public function show(Facility $facility)
    {
        // الأنشطة و التوقيتات المفتوحة لهذه الوحدة
  
$sports = is_array($facility->available_sports)
    ? $facility->available_sports
    : (empty($facility->available_sports) ? [] : explode(',', $facility->available_sports));

// ثم مرر $sports للفيو بدلاً من $facility->activities
return view('front.facilities.show', compact('facility', 'sports'));

}
