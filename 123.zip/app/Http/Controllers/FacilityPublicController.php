<?php

namespace App\Http\Controllers;

use App\Models\Facility;
use App\Models\Member;

class FacilityPublicController extends Controller
{
    // قائمة المرافق
    public function index()
    {
        $facilities = Facility::with(['images']) // تحميل صورة رئيسية إن وجدت
            ->where('status', '!=', 'closed')
            ->orderBy('name')
            ->get();

        // إحصائيات خفيفة لكل مرفق (عدد المنخرطين)
        $membersCount = Member::selectRaw('facility_id, COUNT(*) as total')
            ->groupBy('facility_id')
            ->pluck('total', 'facility_id');

        return view('front.facilities.index', compact('facilities', 'membersCount'));
    }

    // تفاصيل مرفق واحد
    public function show(Facility $facility)
    {
        // تحميل العلاقات اللازمة: الصور + الحصص
        $facility->load([
            'images',
            'clubTimeSlots',
        ]);

        // إحصائيات المنخرطين في هذا المرفق
        $membersCount = Member::where('facility_id', $facility->id)->count();

        // الأنشطة المتاحة (حقل available_sports مصفوفة بفضل الـ cast في الموديل)
        $sports = $facility->available_sports ?? [];

        return view('front.facilities.show', compact('facility', 'membersCount', 'sports'));
    }
}
