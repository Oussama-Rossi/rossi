<?php

namespace App\Http\Controllers;

use App\Models\Member;

class MemberPrintController extends Controller
{
    public function show(Member $member)
    {
        // تأكد إن أردت أن المستخدم لا يطبع إلا استمارته
        // if (auth()->id() !== $member->user_id) { abort(403); }

        return view('members.print-form', compact('member'));
    }
}
