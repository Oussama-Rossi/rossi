<?php

namespace App\Http\Controllers;

use App\Models\Payment;
use App\Services\PaymentGatewayService;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    protected \$paymentService;

    public function __construct(PaymentGatewayService \$paymentService)
    {
        \$this->paymentService = \$paymentService;
        \$this->middleware('auth');
    }

    public function processPayment(Request \$request)
    {
        \$validated = \$request->validate([
            'amount' => 'required|numeric|min:100',
            'gateway' => 'required|in:chargily,cib',
            'booking_id' => 'nullable|exists:bookings,id',
            'ticket_id' => 'nullable|exists:event_tickets,id',
        ]);

        \$payment = Payment::create([
            'transaction_id' => 'TXN-' . uniqid(),
            'user_id' => auth()->id(),
            'amount' => \$validated['amount'],
            'gateway' => \$validated['gateway'],
            'status' => 'processing',
            'booking_id' => \$validated['booking_id'] ?? null,
            'ticket_id' => \$validated['ticket_id'] ?? null,
        ]);

        \$response = \$this->paymentService->processPayment(\$payment, \$validated['gateway']);

        return response()->json(\$response);
    }

    public function handleCallback(Request \$request)
    {
        \$payment = \$this->paymentService->handleGatewayCallback(\$request);

        return response()->json([
            'message' => 'تم معالجة الدفع',
            'payment' => \$payment,
        ]);
    }

    public function getInvoice(Payment \$payment)
    {
        \$this->authorize('view', \$payment);

        return response()->download(\$payment->invoice->pdf_file);
    }
}
