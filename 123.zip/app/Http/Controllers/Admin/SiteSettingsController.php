<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class SiteSettingsController extends Controller
{
    public function edit()
    {
        $logoExists = Storage::disk('public')->exists('logo.png');

        return view('admin.site-settings', compact('logoExists'));
    }

    public function update(Request $request)
    {
        $request->validate([
            'logo' => 'nullable|image|max:2048',
        ]);

        if ($request->hasFile('logo')) {
            if (Storage::disk('public')->exists('logo.png')) {
                Storage::disk('public')->delete('logo.png');
            }

            $request->file('logo')->storeAs('public', 'logo.png');
        }

        return back()->with('success', 'تم تحديث الشعار بنجاح.');
    }
}
