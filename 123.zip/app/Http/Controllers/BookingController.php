<?php

namespace App\Http\Controllers;

use App\Models\Booking;
use App\Models\SportsUnit;
use App\Notifications\BookingApprovedNotification;
use App\Notifications\BookingRejectedNotification;
use Illuminate\Http\Request;

class BookingController extends Controller
{
    public function __construct()
    {
        \$this->middleware('auth');
    }

    public function index()
    {
        \$bookings = Booking::where('user_id', auth()->id())->paginate(10);
        return response()->json(\$bookings);
    }

    public function create(Request \$request)
    {
        \$validated = \$request->validate([
            'unit_id' => 'required|exists:sports_units,id',
            'start_time' => 'required|date_format:Y-m-d H:i',
            'end_time' => 'required|date_format:Y-m-d H:i|after:start_time',
        ]);

        \$unit = SportsUnit::findOrFail(\$validated['unit_id']);

        \$hours = (strtotime(\$validated['end_time']) - strtotime(\$validated['start_time'])) / 3600;
        \$totalPrice = \$hours * \$unit->price_per_hour;

        \$booking = Booking::create([
            'user_id' => auth()->id(),
            'unit_id' => \$unit->id,
            'start_time' => \$validated['start_time'],
            'end_time' => \$validated['end_time'],
            'total_price' => \$totalPrice,
            'status' => 'pending',
        ]);

        return response()->json([
            'message' => 'تم إنشاء الحجز بنجاح',
            'booking' => \$booking,
        ], 201);
    }

    public function approve(Booking \$booking)
    {
        \$this->authorize('approve', \$booking);

        \$booking->approve();
        \$booking->user->notify(new BookingApprovedNotification(\$booking));

        return response()->json([
            'message' => 'تم قبول الحجز',
            'booking' => \$booking,
        ]);
    }

    public function reject(Request \$request, Booking \$booking)
    {
        \$this->authorize('reject', \$booking);

        \$validated = \$request->validate([
            'reason' => 'required|string',
        ]);

        \$booking->reject(\$validated['reason']);
        \$booking->user->notify(new BookingRejectedNotification(\$booking));

        return response()->json([
            'message' => 'تم رفض الحجز',
            'booking' => \$booking,
        ]);
    }
}
