<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Member;

class PublicAuthController extends Controller
{
    // عرض صفحة تسجيل الدخول
    public function showLogin()
    {
        return view('front.auth.login');
    }

    // تنفيذ عملية تسجيل الدخول
public function login(Request $request)
{
    $credentials = $request->validate([
        'email'    => 'required|email',
        'password' => 'required',
    ]);

    if (Auth::attempt($credentials, $request->boolean('remember'))) {
        $request->session()->regenerate();

        $user = Auth::user();

        // مدير عام أو رئيس وحدة → لوحة Filament
        if ($user->isAdmin() || $user->isFacilityManager()) {
            return redirect()->route('filament.admin.pages.dashboard');
        }

        // رئيس جمعية / نادي → بروفيل النادي
        if ($user->isClubManager()) {
            return redirect()->route('club.profile');
        }

        // منخرط عادي → بروفيل المنخرط
        return redirect()->route('public.profile');
    }

    return back()->withErrors([
        'email' => 'بيانات الدخول غير صحيحة.',
    ]);
}

    // تسجيل الخروج
    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect('/');
    }

    // صفحة البروفايل (فضاء المنخرط)
    public function profile()
    {
        // جلب ملف المنخرط المرتبط بالحساب الحالي
        $member = Member::where('user_id', Auth::id())->with('facility')->first();
        
        return view('front.profile', compact('member'));
    }
}
